"""
واجهة نظام توصية السياحة الدينية في مصر (بأزرار اختيار بدل كتابة الأرقام).

Usage:
    python app.py                      # looks for Egypt_Religious_Tourism_Muslim_Christian.csv next to this file
    python app.py path/to/data.csv --port 8000 --no-browser

It starts a LOCAL web page (127.0.0.1 only, nothing is sent anywhere) and opens it in your browser.
Needs only pandas + scikit-learn (already required by religious_trip_recommender.py) - no extra installs.
"""
import argparse
import json
import math
import os
import re
import sys
import threading
import traceback
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from religious_trip_recommender import RecommenderConfig, load_sites, recommend  # noqa: E402

RELIGIONS = {"Islam", "Christianity"}
VISITORS = {"egyptian", "foreign"}
REGIONS = {"Greater Cairo", "Delta & Coast", "Upper Egypt", "Sinai", "Central Egypt"}
MAX_BODY = 2048

SITES = None
CFG = RecommenderConfig()
LOCK = threading.Lock()  # HDBSCAN + shared dataframe: one request at a time is plenty for a local tool


def arabic_notes(notes):
    out = []
    for n in notes:
        m = re.match(r"Only (\d+) of (\d+) days", n)
        if "hand-weighted" in n:
            out.append("ترتيب الأهمية تقدير بأوزان يدوية، مش نتيجة تعلّم آلي.")
        elif "trained machine-learning" in n:
            out.append("ترتيب الأهمية جاي من موديل تعلّم آلي متدرّب على بيانات OpenStreetMap (دقته محدودة خارج القاهرة والإسكندرية).")
        elif "ASSUMED" in n:
            out.append(f"سعر المواصلات ({CFG.transport_egp_per_km:g} جنيه/كم) رقم افتراضي.")
        elif "unknown price" in n:
            out.append(f"بعض المواقع عليها تذكرة سعرها غير معروف، واتحسبت بـ {CFG.unknown_fee_egp:g} جنيه.")
        elif "approximate" in n:
            out.append("إحداثيات بعض الأديرة تقريبية (حوالي 2 كم)، فمكانها على الخريطة ممكن يكون مش دقيق.")
        elif "duplicate" in n:
            out.append("اتدمجت قوائم مكررة لنفس الدير أو المكان.")
        elif m:
            out.append(f"اتخطّط {m.group(1)} من {m.group(2)} أيام بس، بسبب الميزانية أو قلة المواقع في الاختيارات دي.")
        elif "No sites match" in n:
            out.append("مفيش مواقع مطابقة للاختيارات دي.")
        elif "Budget too small" not in n:
            out.append(n)
    return out


def tidy(s):
    """Display-only cleanup of source names: stray space before ')' / after '(' and double spaces."""
    s = s if isinstance(s, str) else ""
    return re.sub(r"\s{2,}", " ", re.sub(r"\(\s+", "(", re.sub(r"\s+\)", ")", s))).strip()


def serialise(plan, budget):
    days = []
    for d in plan.days:
        top = d.stops.loc[d.stops["score"].idxmax()]
        stops = []
        for r in d.stops.itertuples():
            stops.append({
                "name_ar": tidy(r.site_name),
                "name_en": tidy(r.name_en),
                "type": r.site_type,
                "fee": float(r.fee_egp),
                "fee_unknown": bool(r.fee_unknown),
                "lat": float(r.latitude),
                "lon": float(r.longitude),
                "approx": str(getattr(r, "coord_precision", "") or "").startswith("approx"),
            })
        days.append({"day": d.day, "zone": top["site_name"], "region": top["region"], "km": round(d.km, 1),
                     "fees": round(d.fees_egp), "transport": round(d.transport_egp), "total": round(d.total),
                     "stops": stops})
    return {"days": days, "total": round(plan.total), "budget": budget, "notes": arabic_notes(plan.notes)}


def validate(p):
    """Strict whitelist validation; returns (clean_dict, error_message)."""
    if not isinstance(p, dict):
        return None, "bad request"
    religion, visitor = p.get("religion"), p.get("visitor")
    if religion not in RELIGIONS:
        return None, "religion must be Islam or Christianity"
    if visitor not in VISITORS:
        return None, "visitor must be egyptian or foreign"
    b = p.get("budget")
    if isinstance(b, bool) or not isinstance(b, (int, float)) or not math.isfinite(b) or not 0 <= b <= 1_000_000:
        return None, "budget must be a number between 0 and 1,000,000"
    d = p.get("days", 1)
    if isinstance(d, bool) or not isinstance(d, int) or not 1 <= d <= 7:
        return None, "days must be an integer from 1 to 7"
    region = p.get("region")
    if region is not None and region not in REGIONS:
        return None, "unknown region"
    acc = p.get("accessible", False)
    if not isinstance(acc, bool):
        return None, "accessible must be true or false"
    return {"religion": religion, "visitor": visitor, "budget": float(b), "days": d, "region": region,
            "accessible": acc}, None


class Handler(BaseHTTPRequestHandler):
    server_version = "ReligiousTrip/1.0"

    def _send(self, code, body, ctype):
        data = body if isinstance(body, bytes) else body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(data)

    def _json(self, code, obj):
        self._send(code, json.dumps(obj, ensure_ascii=False), "application/json; charset=utf-8")

    def do_GET(self):
        if self.path in ("/", "/index.html"):
            self._send(200, PAGE, "text/html; charset=utf-8")
        else:
            self._json(404, {"error": "not found"})

    def do_POST(self):
        if self.path != "/api/recommend":
            return self._json(404, {"error": "not found"})
        try:
            n = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            n = -1
        if not 0 < n <= MAX_BODY:
            return self._json(400, {"error": "bad request size"})
        try:
            payload = json.loads(self.rfile.read(n).decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            return self._json(400, {"error": "invalid JSON"})
        clean, err = validate(payload)
        if err:
            return self._json(400, {"error": err})
        try:
            with LOCK:
                plan = recommend(SITES, clean["religion"], clean["budget"], clean["visitor"], clean["region"],
                                 clean["days"], clean["accessible"], CFG)
            self._json(200, serialise(plan, clean["budget"]))
        except Exception:
            traceback.print_exc()
            self._json(500, {"error": "internal error"})

    def log_message(self, fmt, *args):  # keep the console quiet
        pass


def main():
    global SITES
    ap = argparse.ArgumentParser()
    scored = os.path.join(HERE, "Egypt_Religious_Tourism_Scored.csv")      # output of train_importance_model.py
    plain = os.path.join(HERE, "Egypt_Religious_Tourism_Muslim_Christian.csv")
    ap.add_argument("csv", nargs="?", default=scored if os.path.exists(scored) else plain)
    ap.add_argument("--port", type=int, default=8000)
    ap.add_argument("--no-browser", action="store_true")
    a = ap.parse_args()
    if not os.path.exists(a.csv):
        sys.exit(f"ملف الداتا مش موجود: {a.csv}")
    SITES = load_sites(a.csv)

    srv = None
    for port in range(a.port, a.port + 20):
        try:
            srv = ThreadingHTTPServer(("127.0.0.1", port), Handler)
            break
        except OSError:
            continue
    if srv is None:
        sys.exit("مفيش بورت فاضي، جرّب --port برقم تاني")
    url = f"http://127.0.0.1:{srv.server_address[1]}"
    print(f"النظام شغال على {url}  (اضغط Ctrl+C للإيقاف)")
    if not a.no_browser:
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nتم الإيقاف.")


PAGE = r"""<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>رحلتك الدينية في مصر</title>
<style>
:root{
  --bg:#f6f5f1; --card:#ffffff; --text:#1d2420; --muted:#5f6b64; --line:#dcdfd9;
  --accent:#0f6b5c; --accent-ink:#ffffff; --accent-soft:#e3f1ed; --warn:#8a5a00; --warn-soft:#fbf0d9;
  --shadow:0 1px 2px rgba(0,0,0,.06);
}
@media (prefers-color-scheme: dark){
  :root{ --bg:#121715; --card:#1b221f; --text:#e8ede9; --muted:#9aa89f; --line:#2f3a35;
    --accent:#3fb8a0; --accent-ink:#06241d; --accent-soft:#183a33; --warn:#e8c070; --warn-soft:#3a2f14; --shadow:none; }
}
*{box-sizing:border-box}
html{-webkit-text-size-adjust:100%}
body{margin:0;background:var(--bg);color:var(--text);
  font:16px/1.65 system-ui,-apple-system,"Segoe UI","Noto Naskh Arabic","Noto Sans Arabic",Tahoma,Arial,sans-serif}
.wrap{max-width:760px;margin:0 auto;padding:24px 16px 56px}
h1{font-size:1.6rem;line-height:1.3;margin:8px 0 4px}
.sub{color:var(--muted);margin:0 0 20px}
.card{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:18px;box-shadow:var(--shadow);margin-bottom:16px}
fieldset{border:0;margin:0 0 18px;padding:0;min-width:0}
legend{font-weight:700;margin-bottom:8px;padding:0}
.step{display:inline-grid;place-items:center;width:1.6em;height:1.6em;border-radius:50%;background:var(--accent-soft);
  color:var(--accent);font-size:.85rem;margin-inline-end:6px}
.pills{display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:10px}
.pill{position:relative;display:block}
.pill input{position:absolute;opacity:0;inset:0;width:100%;height:100%;margin:0;cursor:pointer}
.pill span{display:flex;align-items:center;justify-content:center;gap:8px;min-height:52px;padding:10px 14px;text-align:center;
  border:2px solid var(--line);border-radius:12px;background:var(--card);font-weight:600;transition:border-color .12s,background .12s}
.pill input:hover + span{border-color:var(--accent)}
.pill input:checked + span{border-color:var(--accent);background:var(--accent-soft);color:var(--accent)}
.pill input:focus-visible + span{outline:3px solid var(--accent);outline-offset:2px}
.pill.small span{min-height:44px;font-weight:500}
.budget{display:flex;gap:10px;align-items:center;flex-wrap:wrap}
.budget input[type=text]{flex:1 1 160px;min-height:52px;font:inherit;font-size:1.15rem;padding:8px 14px;border-radius:12px;
  border:2px solid var(--line);background:var(--card);color:var(--text)}
.budget input[type=text]:focus{outline:3px solid var(--accent);outline-offset:1px;border-color:var(--accent)}
.unit{color:var(--muted)}
.chips{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px}
.chip{font:inherit;min-height:40px;padding:4px 14px;border-radius:999px;border:1px solid var(--line);background:var(--card);color:var(--text);cursor:pointer}
.chip:hover{border-color:var(--accent);color:var(--accent)}
.chip:focus-visible{outline:3px solid var(--accent);outline-offset:2px}
.opt{border-top:1px dashed var(--line);padding-top:16px;margin-top:4px}
.check{display:flex;align-items:center;gap:10px;min-height:44px;cursor:pointer}
.check input{width:20px;height:20px;accent-color:var(--accent)}
#go{width:100%;min-height:56px;font:inherit;font-size:1.1rem;font-weight:700;border:0;border-radius:12px;
  background:var(--accent);color:var(--accent-ink);cursor:pointer}
#go:disabled{opacity:.45;cursor:not-allowed}
#go:focus-visible{outline:3px solid var(--text);outline-offset:3px}
#hint{color:var(--muted);text-align:center;margin:8px 0 0;font-size:.95rem}
.error{color:#b42318;background:#fdecea;border-radius:10px;padding:10px 14px;margin-top:12px}
@media (prefers-color-scheme: dark){.error{color:#ffb4a8;background:#3b1b17}}
.summary h2{margin:0 0 4px;font-size:1.2rem}
.meta{color:var(--muted);margin:0 0 12px}
.bar{height:10px;border-radius:99px;background:var(--line);overflow:hidden}
.bar>i{display:block;height:100%;background:var(--accent);border-radius:99px}
.bar.over>i{background:#b42318}
.figs{display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-top:8px;font-weight:600}
.day h3{margin:0;font-size:1.1rem}
.day .dsub{color:var(--muted);margin:2px 0 12px;font-size:.95rem}
ol.stops{list-style:none;margin:0;padding:0}
ol.stops li{display:grid;grid-template-columns:34px 1fr auto;gap:10px;align-items:start;padding:10px 0;border-top:1px solid var(--line)}
ol.stops li:first-child{border-top:0}
.num{width:30px;height:30px;border-radius:50%;background:var(--accent);color:var(--accent-ink);display:grid;place-items:center;font-weight:700;font-size:.9rem}
.nm{font-weight:700;unicode-bidi:plaintext;text-align:right}
.en{color:var(--muted);font-size:.9rem;unicode-bidi:plaintext;text-align:right}
.tags{display:flex;gap:6px;flex-wrap:wrap;margin-top:4px}
.tag{font-size:.8rem;padding:1px 9px;border-radius:99px;background:var(--accent-soft);color:var(--accent)}
.tag.paid{background:var(--warn-soft);color:var(--warn)}
.map{font-size:.9rem;color:var(--accent);white-space:nowrap}
.dtot{border-top:1px solid var(--line);margin-top:6px;padding-top:10px;display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap}
.notes{color:var(--muted);font-size:.92rem;padding-inline-start:20px;margin:6px 0 0}
.empty{text-align:center;color:var(--muted);padding:24px 8px}
.foot{color:var(--muted);font-size:.85rem;text-align:center;margin-top:24px}
[hidden]{display:none!important}
</style>
</head>
<body>
<main class="wrap">
  <h1>رحلتك الدينية في مصر</h1>
  <p class="sub">جاوب على ٣ أسئلة بسيطة وهنرتّبلك رحلة على قد ميزانيتك.</p>

  <form id="form" class="card" novalidate>
    <fieldset>
      <legend><span class="step">١</span>نوع السياحة</legend>
      <div class="pills">
        <label class="pill"><input type="radio" name="religion" value="Islam"><span>🕌 سياحة إسلامية</span></label>
        <label class="pill"><input type="radio" name="religion" value="Christianity"><span>⛪ سياحة مسيحية</span></label>
      </div>
    </fieldset>

    <fieldset>
      <legend><span class="step">٢</span>أنت</legend>
      <div class="pills">
        <label class="pill"><input type="radio" name="visitor" value="egyptian"><span>🇪🇬 مصري</span></label>
        <label class="pill"><input type="radio" name="visitor" value="foreign"><span>🌍 أجنبي</span></label>
      </div>
    </fieldset>

    <fieldset>
      <legend><span class="step">٣</span><label for="budget">ميزانيتك</label></legend>
      <div class="budget">
        <input id="budget" type="text" inputmode="numeric" autocomplete="off" placeholder="مثلاً 500" aria-describedby="hint">
        <span class="unit">جنيه مصري</span>
      </div>
      <div class="chips" aria-label="اختيارات سريعة للميزانية">
        <button type="button" class="chip" data-v="100">100</button>
        <button type="button" class="chip" data-v="300">300</button>
        <button type="button" class="chip" data-v="500">500</button>
        <button type="button" class="chip" data-v="1000">1000</button>
        <button type="button" class="chip" data-v="2000">2000</button>
      </div>
    </fieldset>

    <div class="opt">
      <fieldset>
        <legend>عدد الأيام <span class="unit">(اختياري)</span></legend>
        <div class="pills" style="grid-template-columns:repeat(5,1fr)">
          <label class="pill small"><input type="radio" name="days" value="1" checked><span>1</span></label>
          <label class="pill small"><input type="radio" name="days" value="2"><span>2</span></label>
          <label class="pill small"><input type="radio" name="days" value="3"><span>3</span></label>
          <label class="pill small"><input type="radio" name="days" value="4"><span>4</span></label>
          <label class="pill small"><input type="radio" name="days" value="5"><span>5</span></label>
        </div>
      </fieldset>
      <fieldset>
        <legend>المنطقة <span class="unit">(اختياري)</span></legend>
        <div class="pills">
          <label class="pill small"><input type="radio" name="region" value="" checked><span>كل مصر</span></label>
          <label class="pill small"><input type="radio" name="region" value="Greater Cairo"><span>القاهرة الكبرى</span></label>
          <label class="pill small"><input type="radio" name="region" value="Delta & Coast"><span>الدلتا والساحل</span></label>
          <label class="pill small"><input type="radio" name="region" value="Upper Egypt"><span>الصعيد</span></label>
          <label class="pill small"><input type="radio" name="region" value="Sinai"><span>سيناء</span></label>
          <label class="pill small"><input type="radio" name="region" value="Central Egypt"><span>وسط مصر</span></label>
        </div>
      </fieldset>
      <label class="check"><input type="checkbox" id="accessible"> أماكن مناسبة لذوي الهمم فقط</label>
    </div>

    <button id="go" type="submit" disabled>اقترح لي رحلة</button>
    <p id="hint">اختار نوع السياحة وإنت مصري ولا أجنبي واكتب الميزانية عشان تكمّل.</p>
    <div id="err" class="error" role="alert" hidden></div>
  </form>

  <section id="out" aria-live="polite"></section>
  <p class="foot">الترتيب تقدير بأوزان يدوية، والأسعار والمواصلات تقريبية. راجع الأسعار الرسمية قبل ما تروح.</p>
</main>

<script>
"use strict";
const $ = (s) => document.querySelector(s);
const TYPE_AR = {Mosque: "مسجد", Church: "كنيسة", Cathedral: "كاتدرائية", Monastery: "دير"};
const REGION_AR = {"Greater Cairo": "القاهرة الكبرى", "Delta & Coast": "الدلتا والساحل", "Upper Egypt": "الصعيد",
                   "Sinai": "سيناء", "Central Egypt": "وسط مصر"};
const fmt = (n) => Number(n).toLocaleString("en-US");

function toDigits(s) {  // Arabic-Indic digits -> 0-9, drop thousands separators
  return s.replace(/[٠-٩]/g, (d) => "٠١٢٣٤٥٦٧٨٩".indexOf(d)).replace(/[۰-۹]/g, (d) => "۰۱۲۳۴۵۶۷۸۹".indexOf(d))
          .replace(/[,٬\s]/g, "").replace("٫", ".");
}
const checked = (name) => { const e = document.querySelector(`input[name="${name}"]:checked`); return e ? e.value : null; };
const budgetValue = () => { const t = toDigits($("#budget").value); return /^\d+(\.\d+)?$/.test(t) ? Number(t) : null; };

function refresh() {
  const ok = checked("religion") && checked("visitor") && budgetValue() !== null;
  $("#go").disabled = !ok;
  $("#hint").hidden = !!ok;
}
document.addEventListener("input", refresh);
document.addEventListener("change", refresh);
document.querySelectorAll(".chip").forEach((b) => b.addEventListener("click", () => {
  $("#budget").value = b.dataset.v; refresh(); $("#budget").focus();
}));

function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text !== undefined) e.textContent = text;   // textContent only: data never becomes HTML
  return e;
}

function render(res) {
  const out = $("#out");
  out.replaceChildren();

  const sum = el("div", "card summary");
  sum.append(el("h2", null, res.days.length ? "رحلتك جاهزة" : "مفيش رحلة مناسبة"));
  if (res.days.length) {
    const over = res.total > res.budget;
    sum.append(el("p", "meta", `${res.days.length} ${res.days.length === 1 ? "يوم" : "أيام"} — ` +
      `${res.days.reduce((a, d) => a + d.stops.length, 0)} محطة`));
    const bar = el("div", "bar" + (over ? " over" : ""));
    const fill = document.createElement("i");
    fill.style.width = Math.min(100, res.budget > 0 ? (res.total / res.budget) * 100 : 0) + "%";
    bar.append(fill);
    const figs = el("div", "figs");
    figs.append(el("span", null, `الإجمالي: ${fmt(res.total)} جنيه`),
                el("span", null, `الميزانية: ${fmt(res.budget)} جنيه`),
                el("span", null, `المتبقي: ${fmt(Math.max(0, res.budget - res.total))} جنيه`));
    sum.append(bar, figs);
  } else {
    sum.append(el("p", "empty", "جرّب تزوّد الميزانية، أو تغيّر المنطقة، أو تشيل فلتر ذوي الهمم."));
  }
  out.append(sum);

  res.days.forEach((d) => {
    const card = el("div", "card day");
    card.append(el("h3", null, `اليوم ${d.day} — منطقة ${d.zone}`));
    card.append(el("p", "dsub", `${REGION_AR[d.region] || d.region} · مسافة التنقل حوالي ${d.km} كم`));
    const ol = el("ol", "stops");
    d.stops.forEach((s, i) => {
      const li = document.createElement("li");
      li.append(el("span", "num", String(i + 1)));
      const body = document.createElement("div");
      body.append(el("div", "nm", s.name_ar || s.name_en));
      if (s.name_ar && s.name_en && s.name_ar !== s.name_en) body.append(el("div", "en", s.name_en));
      const tags = el("div", "tags");
      tags.append(el("span", "tag", TYPE_AR[s.type] || s.type));
      tags.append(el("span", "tag" + (s.fee > 0 ? " paid" : ""),
        s.fee === 0 ? "مجاني" : `${fmt(s.fee)} جنيه${s.fee_unknown ? " (سعر تقريبي)" : ""}`));
      if (s.approx) tags.append(el("span", "tag paid", "المكان تقريبي"));
      body.append(tags);
      li.append(body);
      const a = el("a", "map", "الخريطة ↗");
      a.href = `https://www.google.com/maps/search/?api=1&query=${s.lat},${s.lon}`;
      a.target = "_blank"; a.rel = "noopener noreferrer";
      li.append(a);
      ol.append(li);
    });
    card.append(ol);
    const tot = el("div", "dtot");
    tot.append(el("span", null, `تذاكر: ${fmt(d.fees)} جنيه`), el("span", null, `مواصلات: ${fmt(d.transport)} جنيه`),
               el("strong", null, `تكلفة اليوم: ${fmt(d.total)} جنيه`));
    card.append(tot);
    out.append(card);
  });

  if (res.notes.length) {
    const nc = el("div", "card");
    nc.append(el("strong", null, "ملاحظات"));
    const ul = el("ul", "notes");
    res.notes.forEach((n) => ul.append(el("li", null, n)));
    nc.append(ul);
    out.append(nc);
  }
  out.scrollIntoView({behavior: "smooth", block: "start"});
}

$("#form").addEventListener("submit", async (ev) => {
  ev.preventDefault();
  const err = $("#err"); err.hidden = true;
  const b = budgetValue();
  if (!checked("religion") || !checked("visitor") || b === null) return;
  const body = {religion: checked("religion"), visitor: checked("visitor"), budget: b,
                days: Number(checked("days")), region: checked("region") || null, accessible: $("#accessible").checked};
  const btn = $("#go"); btn.disabled = true; btn.textContent = "بجهّز رحلتك...";
  try {
    const r = await fetch("/api/recommend", {method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify(body)});
    const data = await r.json();
    if (!r.ok) throw new Error(data.error || "حصل خطأ");
    render(data);
  } catch (e) {
    err.textContent = "حصل خطأ، جرّب تاني. (" + e.message + ")"; err.hidden = false;
  } finally {
    btn.textContent = "اقترح لي رحلة"; refresh();
  }
});
refresh();
</script>
</body>
</html>
"""

if __name__ == "__main__":
    main()
