import csv,json,math,re,unicodedata
from pathlib import Path
from urllib.parse import quote
from collections import Counter

OUT=Path('outputs'); DATE='2026-11-14'
def readcsv(p): return list(csv.DictReader(Path(p).open(encoding='utf-8-sig',newline='')))
def write(name,rows,cols=None):
    with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=cols or list(rows[0]));w.writeheader();w.writerows(rows)
def km(a,b,c,d):
    x,y=math.radians(float(a)),math.radians(float(c)); z=math.radians(float(d)-float(b))
    return 6371*2*math.asin(min(1,math.sqrt(math.sin((y-x)/2)**2+math.cos(x)*math.cos(y)*math.sin(z/2)**2)))
def values(e,p):
    return [s['mainsnak']['datavalue']['value'] for s in e.get('claims',{}).get(p,[]) if s.get('rank')!='deprecated' and 'datavalue' in s.get('mainsnak',{})]
entities={}
for p in Path('work/entities').glob('*.json'):
    e=json.loads(p.read_text(encoding='utf-8-sig'))['entities'];entities[p.stem]=next(iter(e.values()))
rows=readcsv(OUT/'Christian_Sites_Cleaned_Review.csv')
seeds={r['record_id']:r for r in json.loads(Path('work/evidence_seed.json').read_text(encoding='utf-8'))}
wiki=json.loads(Path('work/wikipedia_batch.json').read_text(encoding='utf-8-sig'))
pages={p['title']:p for p in wiki.get('query',{}).get('pages',{}).values() if 'missing' not in p}
redirects={p['from']:p['to'] for p in wiki.get('query',{}).get('redirects',[])}
audit=[]; evidence=[]; changes=[]; candidates=[]
for r in rows:
    rid=r['record_id'];r['wikidata_original']=r['wikidata']
    r['wikidata_link_status']='not_linked'
    r['wikidata_entity_id']='';r['wikidata_label_en']='';r['wikidata_description_en']=''
    r['wikidata_instance_ids']='';r['inception_claims']='';r['inception_claims_json']='';r['wikidata_revision']='';r['wikidata_url']=''
    r['wikipedia_url']='';r['wikipedia_revision']='';r['wikipedia_excerpt_20_words']=''
    r['coordinate_delta_m']='';r['coordinate_review_status']='source_only_not_ground_verified'
    r['site_type']='unspecified_place_of_worship';r['site_type_basis']='source_amenity_or_name_inference'
    if r['amenity']=='monastery' or re.search(r'\bmonastery\b|\bdeir\b|\bdayr\b|دير',r['name']+' '+r['name_en'],re.I): r['site_type']='monastery_inferred'
    elif re.search(r'\bcathedral\b|كاتدر|كتدر|كاثدر',r['name']+' '+r['name_en'],re.I):r['site_type']='cathedral_inferred'
    r['name_en_language_status']='contains_latin' if re.search('[A-Za-z]',r['name_en']) else 'not_an_english_translation'
    r['themes']='';r['unesco_status']='not_assessed';r['unesco_source_url']='';r['visit_access_status']='not_verified';r['duplicate_review_status']='no_confirmed_merge'
    r['heritage_label']='unassessed';r['label_basis']='research_incomplete';r['evidence_url']='';r['historical_summary']='';r['evidence_claim']='';r['evidence_accessed_on']=''
    original_ids=[x.strip() for x in r['wikidata'].split(';') if x.strip()]
    accepted=original_ids[:]
    if rid=='CHR-0014': accepted=['Q2088356'];r['wikidata_link_status']='corrected_mountain_to_monastery'
    if rid=='CHR-0002': accepted=['Q3320218'];r['wikidata_link_status']='added_manual_identity_match'
    if rid=='CHR-0069': accepted=['Q1356821'];r['wikidata_link_status']='cathedral_selected_organization_separated'
    for q in original_ids:
        e=entities.get(q,{})
        coords=values(e,'P625')
        delta=min((km(r['lat'],r['lon'],c['latitude'],c['longitude'])*1000 for c in coords),default=None)
        audit.append(dict(record_id=rid,input_qid=q,resolved_qid=e.get('id',''),entity_label=e.get('labels',{}).get('en',{}).get('value',''),entity_description=e.get('descriptions',{}).get('en',{}).get('value',''),distance_m=round(delta,1) if delta is not None else '',revision=e.get('lastrevid',''),url=f'https://www.wikidata.org/wiki/{q}',status='wrong_entity_mountain' if q=='Q112628765' else 'organization_not_physical_poi' if q=='Q251268' else 'coordinate_review' if delta is not None and delta>250 else 'coordinate_consistency_only_identity_not_proven',accessed_on=DATE))
    if len(accepted)==1 and accepted[0] in entities:
        q=accepted[0];e=entities[q];resolved=e.get('id',q)
        r['wikidata_entity_id']=resolved;r['wikidata_label_en']=e.get('labels',{}).get('en',{}).get('value','');r['wikidata_description_en']=e.get('descriptions',{}).get('en',{}).get('value','')
        r['wikidata_instance_ids']=';'.join(v.get('id','') for v in values(e,'P31'))
        r['inception_claims']=';'.join(v.get('time','') for v in values(e,'P571'))
        r['inception_claims_json']=json.dumps(values(e,'P571'),ensure_ascii=False)
        r['wikidata_revision']=str(e.get('lastrevid',''));r['wikidata_url']=f'https://www.wikidata.org/wiki/{resolved}'
        if r['wikidata_link_status']=='not_linked':r['wikidata_link_status']='redirect_resolved_identity_pending' if resolved!=q else 'existing_link_identity_pending'
        coords=values(e,'P625');delta=min((km(r['lat'],r['lon'],c['latitude'],c['longitude'])*1000 for c in coords),default=None)
        if delta is not None:
            r['coordinate_delta_m']=str(round(delta,1));r['coordinate_review_status']='cross_source_discrepancy_over_250m' if delta>250 else 'cross_source_consistent_not_ground_verified'
        title=e.get('sitelinks',{}).get('enwiki',{}).get('title','')
        title=redirects.get(title,title);page=pages.get(title)
        if page:
            r['wikipedia_url']=page.get('fullurl','https://en.wikipedia.org/wiki/'+quote(title.replace(' ','_')))
            r['wikipedia_revision']=str(page.get('lastrevid',''))
            r['wikipedia_excerpt_20_words']=' '.join(page.get('extract','').split()[:20])
        r['reference_status']='linked_data_fetched_identity_review_required'
    r['wikidata']=';'.join(accepted);r['has_wikidata']=str(int(bool(accepted)))
    if rid in seeds:
        s=seeds[rid]
        r.update(site_type=s['site_type'],site_type_basis='reviewed_source_name_location_match',themes=s['themes'],historical_summary=s['summary_ar'],heritage_label='documented_significance',label_basis=s['source_type'],evidence_url=s['url'],evidence_claim=s['summary_ar'],evidence_accessed_on=DATE,unesco_status=s['unesco_status'])
        if s['unesco_status']=='tentative_list_component':r['unesco_source_url']='https://whc.unesco.org/en/tentativelists/1827/'
        elif s['unesco_status']=='within_inscribed_property':r['unesco_source_url']='https://whc.unesco.org/en/list/954/'
        evidence.append(dict(evidence_id=f'EV-{rid[4:]}',record_id=rid,claim_ar=s['summary_ar'],source_title=s['source_title'],source_type=s['source_type'],source_url=s['url'],identity_match_basis=s['match_basis'],accessed_on=DATE,label='documented_significance',reviewer='automated_assistant_source_review',review_limit='source-based significance; not field/visitor-access verification'))
    if rid=='CHR-0001':
        r['denomination_standard']='Eastern Orthodox'
        changes.append(dict(record_id=rid,field='denomination_standard',old='Orthodox (unspecified)',new='Eastern Orthodox',reason='UNESCO identifies Greek Orthodox ownership',source_url='https://whc.unesco.org/en/list/954/'))
    if r['wikidata_original']!=r['wikidata']:
        changes.append(dict(record_id=rid,field='wikidata',old=r['wikidata_original'],new=r['wikidata'],reason=r['wikidata_link_status'],source_url=r['wikidata_url']))
    if rid in ('CHR-0103','CHR-0183'):
        r['duplicate_review_status']='possible_same_complex_hold'
    if rid=='CHR-0028':r['wikidata_link_status']='name_and_coordinate_conflict_review'
    if r['recommendation_scope'].startswith('excluded'): r['recommendation_readiness']='excluded_scope'
    elif r['duplicate_review_status']=='possible_same_complex_hold':r['recommendation_readiness']='hold_duplicate_review'
    elif r['coordinate_review_status']=='cross_source_discrepancy_over_250m' or rid=='CHR-0028':r['recommendation_readiness']='hold_location_identity_review'
    elif r['heritage_label']=='documented_significance':r['recommendation_readiness']='offline_candidate_access_unverified'
    else:r['recommendation_readiness']='discovery_only_unassessed'
    search_path=Path(f'work/search/{rid}.json')
    r['additional_search_status']='existing_link_fetched'
    if search_path.exists():
        s=json.loads(search_path.read_text(encoding='utf-8-sig'))
        r['additional_search_status']='rate_limited_research_incomplete' if '429' in str(s.get('error','')) else 'fetch_error_research_incomplete' if 'error' in s else 'candidates_need_identity_review' if s.get('search') else 'no_exact_name_result_not_evidence_of_unimportance'
        for c in s.get('search',[]):
            e=entities.get(c['id'],{});coords=values(e,'P625');delta=min((km(r['lat'],r['lon'],p['latitude'],p['longitude'])*1000 for p in coords),default=None)
            candidates.append(dict(record_id=rid,candidate_qid=c['id'],label=c.get('label',''),description=c.get('description',''),distance_m=round(delta,1) if delta is not None else '',url='https://www.wikidata.org/wiki/'+c['id'],status='accepted_by_manual_review' if c['id'] in accepted else 'candidate_only_not_assigned'))
    r['leakage_group']=rid

# Conservative connected groups for future train/test splits only, never automatic merges.
parent={r['record_id']:r['record_id'] for r in rows}
def root(a):
    while parent[a]!=a:parent[a]=parent[parent[a]];a=parent[a]
    return a
def union(a,b):parent[max(root(a),root(b))]=min(root(a),root(b))
pairs=readcsv(OUT/'Potential_Duplicates.csv')
for p in pairs: union(p['record_id_a'],p['record_id_b'])
for a,b in [('CHR-0081','CHR-0103'),('CHR-0014','CHR-0183'),('CHR-0195','CHR-0196')]:union(a,b)
for r in rows:r['leakage_group']=root(r['record_id'])
write('Christian_Sites_Enriched_Labeled.csv',rows)
write('Evidence_Ledger.csv',evidence)
write('Wikidata_Entity_Audit.csv',audit)
write('Wikidata_Search_Candidates.csv',candidates)
write('Enrichment_Change_Log.csv',changes)
# Correct the earlier single-Q format warning; retain other original findings.
old=readcsv(OUT/'Review_Issues.csv')
corrected=[dict(x,issue='multiple_wikidata_entities',detail='Two syntactically valid IDs: cathedral and patriarchate organization. Resolved separately in enrichment.',review_status='resolved_in_enrichment') if x['issue']=='invalid_wikidata_id' else x for x in old]
write('Review_Issues_Updated.csv',corrected)
metrics=dict(records=len(rows),documented_significance=sum(r['heritage_label']=='documented_significance' for r in rows),unassessed=sum(r['heritage_label']=='unassessed' for r in rows),wikidata_original_entities_fetched=len(audit),wikipedia_pages_linked=sum(bool(r['wikipedia_url']) for r in rows),recommendation_readiness=dict(Counter(r['recommendation_readiness'] for r in rows)),additional_search_status=dict(Counter(r['additional_search_status'] for r in rows)),coordinate_discrepancies=[dict(record_id=r['record_id'],name=r['name'],delta_m=r['coordinate_delta_m']) for r in rows if r['coordinate_review_status']=='cross_source_discrepancy_over_250m'],training_status='content_model_possible; supervised_significance_training_blocked_no_negative_or_relevance_judgments',integration_status='standalone_adapter_only_awaiting_Travora_repository',islamic_comparison_status='awaiting_model_data_and_shared_evaluation_set')
(OUT/'Enrichment_Summary.json').write_text(json.dumps(metrics,ensure_ascii=False,indent=2),encoding='utf-8')
assert len(rows)==238 and len({r['record_id'] for r in rows})==238
assert all(r['evidence_url'] for r in rows if r['heritage_label']=='documented_significance')
assert all(r['heritage_label']!='negative' for r in rows)
assert all(len(r['wikipedia_excerpt_20_words'].split())<=20 for r in rows)
print(json.dumps(metrics,ensure_ascii=False,indent=2))
