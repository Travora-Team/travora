import csv,json,shutil,hashlib,zipfile
from pathlib import Path
from collections import Counter
OUT=Path('outputs');PKG=OUT/'Travora_Christian_Package'
def read(p):return list(csv.DictReader(Path(p).open(encoding='utf-8-sig',newline='')))
def write(p,rows,cols=None):
    with Path(p).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=cols or list(rows[0]));w.writeheader();w.writerows(rows)
rows=read(OUT/'Christian_Sites_Enriched_Labeled.csv')
pending=[];search=[]
for r in rows:
    todo=[]
    if r['heritage_label']=='unassessed':todo.append('research_significance_without_negative_assumption')
    if r['recommendation_readiness'].startswith('hold_location'):todo.append('resolve_coordinate_or_identity_conflict')
    if r['recommendation_readiness'].startswith('hold_duplicate'):todo.append('resolve_complex_vs_duplicate')
    if r['wikidata_link_status'] in ('existing_link_identity_pending','redirect_resolved_identity_pending'):todo.append('verify_link_identity_not_only_coordinate')
    todo.append('verify_visitor_access_before_live_itinerary')
    pending.append(dict(record_id=r['record_id'],name=r['name'],priority='high' if r['recommendation_readiness'].startswith('hold') else 'normal',heritage_label=r['heritage_label'],actions=';'.join(todo),search_status=r['additional_search_status'],readiness=r['recommendation_readiness'],review_decision='',reviewer='',review_date=''))
    p=Path('work/search')/(r['record_id']+'.json');d=json.loads(p.read_text(encoding='utf-8-sig')) if p.exists() else {}
    query=d.get('searchinfo',{}).get('search',d.get('query',''))
    search.append(dict(record_id=r['record_id'],query=query,status=r['additional_search_status'],error=d.get('error',''),result_count=len(d.get('search',[])) if p.exists() and 'error' not in d else '',accessed_on='2026-11-14'))
write(OUT/'Pending_Review.csv',pending);write(OUT/'Search_Attempt_Log.csv',search)
pairs=read(OUT/'Potential_Duplicates.csv')
keys={frozenset([p['record_id_a'],p['record_id_b']]) for p in pairs}
lookup={r['record_id']:r for r in rows}
for a,b in [('CHR-0081','CHR-0103'),('CHR-0014','CHR-0183'),('CHR-0195','CHR-0196')]:
    if frozenset([a,b]) not in keys:
        pairs.append(dict(record_id_a=a,osm_id_a=lookup[a]['osm_id'],name_a=lookup[a]['name'],record_id_b=b,osm_id_b=lookup[b]['osm_id'],name_b=lookup[b]['name'],distance_m='',signals='possible_same_named_complex_alias',decision='manual_review_no_merge'))
for p in pairs:
    p['review_outcome']='unresolved_no_merge'
    p['rationale']='Same name or proximity is insufficient to identify a duplicate.'
    if 'same_normalized_name' in p['signals'] and p['distance_m'] and float(p['distance_m'])>1000:p['rationale']='Name-only match across distant points; keep separate pending identity check.'
write(OUT/'Potential_Duplicates_Reviewed.csv',pairs)
files=['Christian_Sites_Enriched_Labeled.csv','Evidence_Ledger.csv','Wikidata_Entity_Audit.csv','Wikidata_Search_Candidates.csv','Enrichment_Change_Log.csv','Review_Issues_Updated.csv','Pending_Review.csv','Search_Attempt_Log.csv','Potential_Duplicates_Reviewed.csv','Enrichment_Summary.json']
for name in files:shutil.copy2(OUT/name,PKG/name)
shutil.copy2('C:/Users/Seddek Mohamed/AppData/Local/Packages/5319275A.WhatsAppDesktop_cv1g1gvanyjgm/LocalState/sessions/B68B477B0FEEBAAC426BB5D3F044004143CF5AB6/transfers/2026-46/Final_Cleaned_Christian_Sites.csv',PKG/'Source_Original_238.csv')
schema={'heritage_label':{'documented_significance':'A cited source supports specific historic, artistic, or official tourist-route significance; not a visitor-access certification.','unassessed':'Research incomplete or identity/evidence insufficient; never encode as zero or negative.'},'source_status_is_not_target':True,'proposed_label_is_not_gold':True,'gold_significance_labels':{'1':'Explicitly adjudicated significant under a written project rubric.','0':'Explicitly adjudicated outside the project significance rubric, with substantive rationale; not missing documentation.'},'query_relevance_grades':{'0':'not relevant to the particular query','1':'marginally relevant','2':'relevant','3':'highly relevant'},'live_recommendation_requirements':['verified entity identity','resolved duplicates','verified coordinates','visitor access checked','real routing/time/budget constraints'], 'date':'2026-11-14'}
(PKG/'Label_Schema.json').write_text(json.dumps(schema,ensure_ascii=False,indent=2),encoding='utf-8')
manifest={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in PKG.iterdir() if p.is_file() and p.name!='SHA256_Manifest.json'}
(PKG/'SHA256_Manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
archive=OUT/'Travora_Christian_Research_and_Model.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(PKG.iterdir()):
        if p.is_file():z.write(p,p.name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,h in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==h
assert len(read(PKG/'Christian_Sites_Enriched_Labeled.csv'))==238
assert all(r['gold_label']=='' for r in read(PKG/'Significance_Adjudication.csv'))
print(json.dumps(dict(package_files=len(manifest)+1,archive_bytes=archive.stat().st_size,duplicate_review_pairs=len(pairs),labels=dict(Counter(r['heritage_label'] for r in rows))),indent=2))
