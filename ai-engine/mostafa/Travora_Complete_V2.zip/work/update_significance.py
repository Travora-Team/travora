import csv
import json
import re
from pathlib import Path

root = Path(__file__).resolve().parents[1]
folder = root / 'outputs' / 'Travora_Test'
sources = json.loads((root / 'work' / 'verified_significance.json').read_text('utf-8'))
page = folder / 'Travora.html'
html = page.read_text('utf-8')
pattern = r'const data=(.*?);\s*const el='
data = json.loads(re.search(pattern, html, re.S)[1])
report = ['# مراجعة دليل الأهمية في كتالوج Travora', '',
          'تاريخ الفحص 16 نوفمبر 2026. فُحصت حالة التوثيق لكل السجلات المعروضة، واختيرت مواقع من رتب مختلفة لمطابقتها بمصادر خارجية. يغطي التقرير الإضافات المؤكدة في هذه الجولة. درجات الترتيب من النموذجين السابقين.', '']
matched = set()
for faith, cards in data.items():
    path = folder / (faith + '.csv')
    with path.open(encoding='utf-8-sig', newline='') as f:
        rows = list(csv.DictReader(f))
    group = 'الإسلامية' if faith == 'Islam' else 'المسيحية'
    report.extend(['## المواقع ' + group, ''])
    assert len(rows) == len(cards)
    for row, card in zip(rows, cards):
        sid = row['site_id']
        assert sid == card[0]
        if sid not in sources:
            continue
        url, claim = sources[sid]
        matched.add(sid)
        row.update(evidence_url=url, evidence_claim=claim, evidence_accessed_on='2026-11-16',
                   heritage_label='documented_significance', historical_summary=claim,
                   reference_status='site_specific_source_verified', label_basis='site_specific_source',
                   additional_search_status='site_specific_source_verified')
        if row['recommendation_readiness'] == 'discovery_only_unassessed':
            row['recommendation_readiness'] = 'offline_candidate_access_unverified'
        card[7], card[13], card[14] = url, row['heritage_label'], claim
        report.extend([f"- {row['site_name']} (الترتيب {card[5]}، المعرّف `{sid}`). {claim} [المصدر]({url})", ''])
    total = sum(r['heritage_label'] == 'documented_significance' for r in rows)
    report.extend([f'بعد التحديث يوجد دليل مسجل لـ {total} من {len(rows)} موقعًا. عدد المواقع دون دليل أهمية مسجل هو {len(rows)-total}.', ''])
    with path.open('w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)
assert matched == sources.keys()
payload = json.dumps(data, ensure_ascii=False).replace('<', '\\u003c')
html = re.sub(pattern, lambda _: 'const data=' + payload + ';\nconst el=', html, flags=re.S)
html = html.replace(' مواقع لها دليل أهمية فقط', ' عرض المواقع التي لها دليل أهمية مسجّل')
html = html.replace(' · الدرجة ', ' · درجة النموذج ')
page.write_text(html, 'utf-8')
report.extend(['## حدود التحقق', '', 'درجة النموذج تحدد الترتيب داخل القسم. تصنيف الأهمية التاريخية للمواقع الأخرى ما زال غير محسوم، ويتطلب ربط كل مكان بمصدر يحدد هويته وأهميته. ولا يتضمن هذا الفحص التحقق من مواعيد الزيارة أو إعادة تدريب النموذجين.'])
(folder / 'Significance_Report_AR.md').write_text('\n'.join(report)+'\n', 'utf-8')
