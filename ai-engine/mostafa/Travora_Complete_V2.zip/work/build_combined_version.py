"""Create the standalone mixed catalogue and complete V2 delivery from the verified V1 package."""
import csv
import json
import re
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

root = Path(__file__).resolve().parents[1]
outputs = root / 'outputs'
old = outputs / 'Travora_Test'
new = outputs / 'Travora_V2'
new.mkdir(exist_ok=True)
rows = []
for section in ('Islam', 'Christianity'):
    with (old / f'{section}.csv').open(encoding='utf-8-sig', newline='') as source:
        rows.extend(csv.DictReader(source))
with (new / 'Travora_Sites.csv').open('w', encoding='utf-8-sig', newline='') as dest:
    writer = csv.DictWriter(dest, fieldnames=list(dict.fromkeys(k for r in rows for k in r)))
    writer.writeheader()
    writer.writerows(rows)

page = (old / 'Travora.html').read_text('utf-8')
page = page.replace('اختبار توصيات المزارات', 'مزارات مصر الدينية').replace('اختبار التوصيات', 'مزارات مصر')
page = page.replace('<nav><button', '<nav aria-label="نوع المزارات"><button id="both">كل المزارات</button><button', 1)
page = page.replace('<p id="count"', '<details id="trip"><summary>رحلتي (<span id="tripSize">0</span>)</summary><ol id="stops"></ol></details><p id="count"')
start = page.index('function select(m)')
end = page.index('el(\'mus\').onclick', start)
card = page[page.index("show.map(r=>", start)+len("show.map(r=>"):page.index(").join('')||", start)]
card = card.replace("'<article><b>'", "'<article><small>'+faithName.get(r)+'</small><br><b>'")
card = card.replace("</details></article>", "</details><button data-pick=\"'+esc(r[0])+'\" aria-pressed=\"'+picked.has(r[0])+'\">'+(picked.has(r[0])?'إزالة من رحلتي':'إضافة إلى رحلتي')+'</button></article>")
script = """
const faithName = new Map();
const byId = new Map();
for (const [faith, rows] of Object.entries(data)) {
  for (const row of rows) {
    faithName.set(row, faith === 'Islam' ? 'مزار إسلامي' : 'مزار مسيحي');
    byId.set(row[0], row);
  }
}
const picked = new Set();
const buttons = {All:'both', Islam:'mus', Christianity:'chr'};
function select(section) {
  model = section;
  for (const [key, id] of Object.entries(buttons)) el(id).setAttribute('aria-pressed', key === section);
  const rows = section === 'All' ? [...byId.values()] : data[section];
  const region = el('reg').options.length ? el('reg').value : '*';
  const regions = [...new Set(rows.map(row => row[3]))].sort();
  el('reg').replaceChildren(new Option('كل المناطق','*'));
  for (const value of regions) el('reg').add(new Option(value || 'المنطقة غير مسجلة',value));
  if (regions.includes(region)) el('reg').value = region;
  el('info').textContent = section === 'All' ? 'تُعرض النتائج بالتناوب بين القسمين، حسب ترتيب كل نموذج.' :
    section === 'Islam' ? 'النتائج حسب ترتيب النموذج الإسلامي.' : 'النتائج حسب التشابه مع أمثلة المواقع المسيحية الموثقة.';
  render();
}
function matches(row) {
  return (el('reg').value === '*' || el('reg').value === row[3]) &&
    normal(row.slice(0,3).join(' ')).includes(normal(el('q').value.trim())) &&
    (!el('doc').checked || row[13] === 'documented_significance');
}
function render() {
  let found;
  if (model === 'All') {
    const a = data.Islam.filter(matches), b = data.Christianity.filter(matches);
    found = [];
    for (let i=0; i<Math.max(a.length,b.length); i++) {
      if (a[i]) found.push(a[i]);
      if (b[i]) found.push(b[i]);
    }
  } else found = data[model].filter(matches);
  const show = found.slice(0, Number(el('limit').value));
  el('count').textContent = 'معروض '+show.length+' من '+found.length+' نتيجة مطابقة';
  el('results').innerHTML = show.map(r => CARD).join('') || 'لا توجد نتائج مطابقة.';
  el('tripSize').textContent = picked.size;
  el('stops').innerHTML = [...picked].map(id => {
    const row = byId.get(id);
    return '<li>'+esc(row[1])+' · '+faithName.get(row)+' <button data-pick="'+esc(id)+'">إزالة</button></li>';
  }).join('');
}
for (const [key, id] of Object.entries(buttons)) el(id).onclick = () => select(key);
for (const id of ['q','reg','doc','limit']) el(id).oninput = render;
document.addEventListener('click', event => {
  const id = event.target.closest('button[data-pick]')?.dataset.pick;
  if (!byId.has(id)) return;
  if (picked.has(id)) picked.delete(id); else picked.add(id);
  render();
});
select('All');
"""
payload = json.loads(re.search(r'const data=(.*?);\s*const el=', page, re.S)[1])
cards = [r for section in payload.values() for r in section]
assert len({r[0] for r in cards}) == len(rows) == len(cards)
page = page[:start] + script.replace('CARD',card) + page[page.index('</script>',end):]
(new / 'Travora.html').write_text(page,'utf-8')
guide = """# Travora — الإصدار الثاني

فك الضغط وافتح Travora.html مباشرة. تعرض الواجهة 893 موقعًا، منها 571 إسلاميًا و322 مسيحيًا. يمكنك اختيار قسم أو البحث في الاثنين معًا وتصفية النتائج بالمنطقة أو دليل الأهمية. اضغط «إضافة إلى رحلتي» لتكوين قائمة زيارات من القسمين خلال الجلسة الحالية. تُفرغ القائمة عند إعادة تحميل الصفحة.

يجمع Travora_Sites.csv السجلات المعروضة. تحتفظ المواقع بترتيبها داخل نموذجها. في العرض المشترك تتناوب النتائج المطابقة من القسمين. ملفات المشروع والنماذج والبيانات الأصلية وتقارير المراحل السابقة موجودة في مجلدات work وinputs وoutputs داخل الحزمة الكاملة.
"""
(new / 'START_HERE_AR.md').write_text(guide,'utf-8')
with ZipFile(outputs / 'Travora_Complete_Project.zip') as previous, ZipFile(outputs / 'Travora_Complete_V2.zip','w',ZIP_DEFLATED) as archive:
    for entry in previous.namelist():
        if entry != 'START_HERE_AR.md':
            archive.writestr(entry, previous.read(entry))
    for file in sorted(new.iterdir()):
        if file.is_file():
            archive.write(file,file.name)
    archive.write(__file__, 'work/build_combined_version.py')
