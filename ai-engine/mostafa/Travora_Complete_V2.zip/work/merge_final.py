from merge_inputs import *
from collections import Counter
out=Path("outputs")
rows=[r.copy() for r in old]
index={r["site_id"]:r for r in rows}
assert len(index)==len(old)
# Reviewed transliterations or distinctive names in the same locality.
aliases=dict(zip([2,99,14,115,25,100,26,146,12,61,79,92,59,60,1,97,89,98,86,76,96,85,24,144,80,174,81,90,158], [71,32,116,30,129,114,130,24,78,3,109,107,99,9,118,103,41,112,73,47,37,84,123,58,22,40,108,83,36]))
manual={i:f"MON_{j:03}" for i,j in aliases.items()}
manual.update({141:"ICONIC_005",19:"ICONIC_006",27:"OSM_14107011012",173:"OSM_14097173719",108:"OSM_673417163"})
audit=[]
for n in new:
 k=int(n["record_id"][4:]); oid="OSM_"+n["osm_id"].split("/")[-1];o=index.get(oid)
 if o and o["religion"]=="Christianity" and dist(o,n)<100: method="OSM number and coordinates"
 elif k in manual:
  o=index[manual[k]];assert o["religion"]=="Christianity" and dist(o,n)<500;method="reviewed name and location"
 else:o=None;method="added"
 if o is None:
  o=dict(site_id=n["site_id"],religion="Christianity",site_name=n["name"],latitude=n["latitude"],longitude=n["longitude"],source="OSM",site_type="Monastery" if "monastery" in n["site_type"] else "Church" if "church" in n["site_type"] else n["site_type"],needs_review="True");rows.append(o)
 assert not o.get("record_id")
 for field in ("ml_label","ml_importance","denomination","wikidata","name_en"):
  o["prior_"+field]=o.get(field,"")
 for field,v in n.items():
  if field not in old[0]:o[field]=v
 o.update(ml_label=n["ml_label"],ml_importance=n["ml_importance"],denomination=n["denomination_standard"],name_en=n["name_en"],wikidata=n["wikidata"] or o.get("wikidata",""),osm_id=n["osm_id"],merge_status=method)
 if n["wikipedia_url"] and not o.get("wikipedia"):o["wikipedia"]=n["wikipedia_url"]
 o["christian_site_type"]=n["site_type"];o["christian_raw_denomination"]=n["denomination"]
 for field in ("latitude","longitude","site_id"):o["christian_"+field]=n[field]
 close=near(n) if method=="added" else []
 audit.append(dict(record_id=n["record_id"],merged_site_id=o["site_id"],decision=method,nearby_old_candidates=" | ".join(f"{i} ({d:.0f} m)" for d,i,s in close if d<=500)))
def save(name,data):
 with (out/name).open("w",newline="",encoding="utf-8-sig") as f:
  w=csv.DictWriter(f,fieldnames=list(dict.fromkeys(k for r in data for k in r)));w.writeheader();w.writerows(data)
save("Egypt_Religious_Tourism_Merged_Scored.csv",rows)
save("Christian_Merge_Audit.csv",audit)
saved=read(out/"Egypt_Religious_Tourism_Merged_Scored.csv")
assert len({r["site_id"] for r in saved})==len(saved)
assert {r["record_id"] for r in saved if r["record_id"]}=={n["record_id"] for n in new}
assert all(all(s[k]==v for k,v in o.items()) for s,o in zip(saved,old) if o["religion"]=="Islam")
print(Counter(a["decision"] for a in audit),Counter(r["religion"] for r in saved),len(saved),sum(bool(a["nearby_old_candidates"]) for a in audit))
