import csv, json, math, re, unicodedata
from pathlib import Path
from collections import Counter

src=Path('C:/Users/Seddek Mohamed/AppData/Local/Packages/5319275A.WhatsAppDesktop_cv1g1gvanyjgm/LocalState/sessions/B68B477B0FEEBAAC426BB5D3F044004143CF5AB6/transfers/2026-46/Final_Cleaned_Christian_Sites.csv')
out=Path('outputs')
rows=list(csv.DictReader(src.open(encoding='utf-8-sig',newline='')))
fields=list(rows[0])
def norm(s):
    s=unicodedata.normalize('NFKC',s).casefold()
    s=re.sub('[\u064b-\u065f\u0670ـ]','',s)
    return re.sub(r'[^\w]+',' ',s).strip()
def distance(a,b):
    x,y=math.radians(float(a['lat'])),math.radians(float(b['lat']))
    dx=y-x; dy=math.radians(float(b['lon'])-float(a['lon']))
    return 6371000*2*math.asin(min(1,math.sqrt(math.sin(dx/2)**2+math.cos(x)*math.cos(y)*math.sin(dy/2)**2)))
issues=[]; cleaned=[]; removed=[]; seen={}
def issue(r,code,detail):
    issues.append(dict(record_id=r['record_id'],osm_id=r['osm_id'],name=r['name'],issue=code,detail=detail,review_status='pending'))
for i,raw in enumerate(rows,1):
    r={k:unicodedata.normalize('NFC',v or '').strip() for k,v in raw.items()}
    r['record_id']=f'CHR-{i:04d}'
    r['source_row']=str(i+1)
    r['denomination_standard_original']=raw['denomination_standard']
    d=r['denomination'].lower()
    if not d: r['denomination_standard']='Unknown'
    elif d=='orthodox': r['denomination_standard']='Orthodox (unspecified)'
    elif d in ('coptic','koptic'): r['denomination_standard']='Coptic (branch unspecified)'
    if r['denomination_standard']!=raw['denomination_standard']:
        issue(r,'denomination_mapping_corrected','Removed unsupported denomination specificity; original retained.')
    try:
        lat,lon=float(r['lat']),float(r['lon'])
        valid=math.isfinite(lat) and math.isfinite(lon) and -90<=lat<=90 and -180<=lon<=180
    except ValueError: valid=False
    r['coordinate_status']='valid_numeric_range' if valid else 'invalid'
    if not valid: issue(r,'invalid_coordinates','Missing, nonnumeric or outside global coordinate range.')
    elif not (22<=lat<=32 and 24<=lon<=37): issue(r,'outside_egypt_screening_box','Outside approximate screening box; not a national boundary test.')
    # Name-based screening is a review signal, never an automatic exclusion.
    excluded=r['amenity'] in ('school','college','university','grave_yard') or r['landuse']=='cemetery'
    r['recommendation_scope']='excluded_school_or_cemetery' if excluded else 'candidate_pending_verification'
    if re.search(r'مدرس|مقابر|مقبرة|\bschool\b|\bcemetery\b|\bgraveyard\b',r['name']+' '+r['name_en'],re.I):
        issue(r,'school_cemetery_name_signal','Review name signal and classification before inclusion.')
    if not r['name'] and not r['name_en']: issue(r,'missing_name','No Arabic/local or English name.')
    if not re.fullmatch(r'(node|way|relation)/\d+',r['osm_id']): issue(r,'invalid_osm_id','Unexpected OSM identifier format.')
    r['reference_status']='wikidata_id_unverified' if r['wikidata'] else 'no_external_reference_in_file'
    if r['wikidata'] and not re.fullmatch(r'Q[1-9]\d*',r['wikidata']): issue(r,'invalid_wikidata_id','Unexpected Wikidata identifier format.')
    if r['has_wikidata']!=str(int(bool(r['wikidata']))): issue(r,'wikidata_flag_mismatch','Flag disagrees with identifier presence.')
    r['has_wikidata']=str(int(bool(r['wikidata'])))
    r['heritage_label']='unassessed'
    r['site_type_status']='osm_tag_only_unverified'
    r['historical_summary']=''; r['evidence_url']=''; r['evidence_claim']=''; r['evidence_accessed_on']=''
    key=tuple(r[k] for k in fields)
    if key in seen:
        removed.append(dict(record_id=r['record_id'],duplicate_of=seen[key],reason='exact_normalized_record'))
    else: seen[key]=r['record_id']; cleaned.append(r)
pairs=[]
for i,a in enumerate(cleaned):
    for b in cleaned[i+1:]:
        reasons=[]
        if a['osm_id']==b['osm_id']: reasons.append('same_osm_id')
        if a['wikidata'] and a['wikidata']==b['wikidata']: reasons.append('same_wikidata')
        same=any(norm(a[k]) and norm(a[k])==norm(b[k]) for k in ('name','name_en'))
        dist=distance(a,b) if a['coordinate_status']==b['coordinate_status']=='valid_numeric_range' else None
        if same: reasons.append('same_normalized_name')
        if dist is not None and dist<=100: reasons.append('within_100m')
        if reasons:
            pairs.append(dict(record_id_a=a['record_id'],osm_id_a=a['osm_id'],name_a=a['name'],record_id_b=b['record_id'],osm_id_b=b['osm_id'],name_b=b['name'],distance_m=round(dist,1) if dist is not None else '',signals=';'.join(reasons),decision='manual_review_no_merge'))
def write(name,data,headers):
    with (out/name).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=headers); w.writeheader(); w.writerows(data)
write('Christian_Sites_Cleaned_Review.csv',cleaned,list(cleaned[0]))
write('Review_Issues.csv',issues,['record_id','osm_id','name','issue','detail','review_status'])
write('Potential_Duplicates.csv',pairs,['record_id_a','osm_id_a','name_a','record_id_b','osm_id_b','name_b','distance_m','signals','decision'])
write('Removed_Exact_Duplicates.csv',removed,['record_id','duplicate_of','reason'])
metrics=dict(source_records=len(rows),output_records=len(cleaned),exact_duplicates_removed=len(removed),christian_records=sum(r['religion']=='christian' for r in rows),wikidata_ids_present=sum(bool(r['wikidata']) for r in rows),missing_denomination=sum(not r['denomination'] for r in rows),missing_local_name=sum(not r['name'] for r in rows),schools_or_cemeteries_excluded=sum(r['recommendation_scope'].startswith('excluded') for r in cleaned),invalid_coordinates=sum(r['coordinate_status']=='invalid' for r in cleaned),potential_duplicate_pairs=len(pairs),issue_counts=dict(Counter(r['issue'] for r in issues)))
(out/'Validation_Summary.json').write_text(json.dumps(metrics,ensure_ascii=False,indent=2),encoding='utf-8')
assert len(cleaned)+len(removed)==len(rows)
assert len({r['record_id'] for r in cleaned})==len(cleaned)
assert all(r['heritage_label']=='unassessed' for r in cleaned)
for path in out.glob('*.csv'):
    with path.open(encoding='utf-8-sig',newline='') as f: list(csv.DictReader(f))
print(json.dumps(metrics,ensure_ascii=False,indent=2))
