$ErrorActionPreference='Stop'
$jobs=Get-Content work/wiki_jobs.json -Raw | ConvertFrom-Json
$extra=[pscustomobject]@{qid='Q3320218';title='Monastery of Saint Macarius the Great'}
$jobs=@($jobs)+@($extra)
$titles=($jobs.title | Sort-Object -Unique) -join '|'
$url='https://en.wikipedia.org/w/api.php?action=query&prop=extracts%7Cinfo&exintro=1&explaintext=1&inprop=url&redirects=1&format=json&titles='+[Uri]::EscapeDataString($titles)
try {
    $r=Invoke-WebRequest -Uri $url -TimeoutSec 30 -Headers @{'User-Agent'='TravoraDataValidation/1.0'}
    [System.IO.File]::WriteAllText((Join-Path (Get-Location) 'work/wikipedia_batch.json'),$r.Content,[System.Text.UTF8Encoding]::new($false))
    'Wikipedia batch fetched'
} catch { $_.Exception.Message }
