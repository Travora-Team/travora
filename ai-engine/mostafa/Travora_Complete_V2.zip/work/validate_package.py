import csv,json,sys,math,unittest,hashlib
from pathlib import Path
ROOT=Path('outputs/Travora_Christian_Package')
sys.path.insert(0,str(ROOT.resolve()))
from christian_ranker import ChristianRecommender,train,distance_km
from compare_rankings import compare
from train_supervised import run

rows=list(csv.DictReader(Path('outputs/Christian_Sites_Enriched_Labeled.csv').open(encoding='utf-8-sig')))
def csvfile(path,cols,data):
    with Path(path).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=cols);w.writeheader();w.writerows(data)
csvfile(ROOT/'Significance_Adjudication.csv',['record_id','leakage_group','proposed_label','gold_label','reviewer','rationale','evidence_url','review_date'],[dict(record_id=r['record_id'],leakage_group=r['leakage_group'],proposed_label='1' if r['heritage_label']=='documented_significance' else '',gold_label='',reviewer='',rationale='',evidence_url=r['evidence_url'],review_date='') for r in rows])
csvfile(ROOT/'Relevance_Judgments.csv',['query_id','query_text','record_id','relevance','reviewer'],[])
csvfile(ROOT/'Islamic_Predictions.csv',['query_id','record_id','score'],[])
csvfile(ROOT/'Christian_Predictions.csv',['query_id','record_id','score'],[])
model_path=ROOT/'christian_content_model.json'
rec=ChristianRecommender(model_path)
class Checks(unittest.TestCase):
    def test_source_integrity(self):
        self.assertEqual(len(rows),238)
        self.assertEqual(rec.model['source_sha256'],hashlib.sha256(Path('outputs/Christian_Sites_Enriched_Labeled.csv').read_bytes()).hexdigest())
    def test_vectors_normalized(self):
        for v in rec.model['vectors'].values():self.assertAlmostEqual(sum(x*x for x in v.values()),1)
    def test_known_exact_name_ranks_first(self):
        self.assertEqual(rec.recommend('Hanging Church',limit=1)[0]['record_id'],'CHR-0141')
    def test_holdouts_excluded(self):
        got=rec.recommend('church monastery',origin=(30,31),limit=238,discovery=True)
        holds={r['record_id'] for r in rows if r['recommendation_readiness'].startswith('hold')}
        self.assertFalse(holds & {r['record_id'] for r in got})
    def test_unassessed_not_in_strict_mode(self):
        self.assertTrue(all(r['heritage_label']=='documented_significance' for r in rec.recommend('church monastery',limit=238)))
    def test_access_gate(self):
        self.assertEqual(rec.recommend('church',require_verified_access=True),[])
    def test_radius(self):
        got=rec.recommend('church',origin=(30.005,31.230),max_distance_km=2,limit=238)
        self.assertTrue(got);self.assertTrue(all(r['distance_km_straight_line']<=2 for r in got))
    def test_components_and_cf(self):
        got=rec.recommend('',collaborative_scores={'CHR-0141':1},weights={'content':0,'distance':0,'collaborative':1})
        self.assertEqual(got[0]['record_id'],'CHR-0141');self.assertAlmostEqual(got[0]['score'],1)
    def test_missing_cf_renormalization(self):
        for r in rec.recommend('church',origin=(30,31)):
            self.assertNotIn('collaborative',r['active_weights']);self.assertAlmostEqual(sum(r['active_weights'].values()),1)
    def test_invalid_inputs(self):
        for kwargs in ({'origin':(math.nan,31)},{'origin':(91,31)},{'collaborative_scores':{'CHR-0141':2}},{'collaborative_scores':{'fake':0.3}},{'max_distance_km':2},{'limit':0}):
            with self.assertRaises(ValueError):rec.recommend('church',**kwargs)
        with self.assertRaises(ValueError):rec.recommend('zzzzzzzz')
    def test_no_labels_become_negative(self):
        status=run('outputs/Christian_Sites_Enriched_Labeled.csv',ROOT/'Significance_Adjudication.csv',ROOT)
        self.assertEqual(status['status'],'not_trained');self.assertEqual(status['gold_records'],0)
    def test_comparison_no_fabricated_metrics(self):
        result=compare(ROOT/'Relevance_Judgments.csv',ROOT/'Christian_Predictions.csv',ROOT/'Islamic_Predictions.csv')
        self.assertEqual(result['status'],'not_evaluated')
    def test_comparison_formula_and_pool_gate(self):
        temp=Path('work/eval_fixture');temp.mkdir(exist_ok=True)
        csvfile(temp/'j.csv',['query_id','record_id','relevance','reviewer'],[dict(query_id='q',record_id='a',relevance=3,reviewer='fixture'),dict(query_id='q',record_id='b',relevance=0,reviewer='fixture')])
        csvfile(temp/'a.csv',['query_id','record_id','score'],[dict(query_id='q',record_id='a',score=1),dict(query_id='q',record_id='b',score=0)])
        csvfile(temp/'b.csv',['query_id','record_id','score'],[dict(query_id='q',record_id='a',score=0),dict(query_id='q',record_id='b',score=1)])
        v=compare(temp/'j.csv',temp/'a.csv',temp/'b.csv',1)
        self.assertEqual(v['results']['christian']['macro_ndcg_at_k'],1);self.assertEqual(v['results']['islamic']['macro_ndcg_at_k'],0)
        csvfile(temp/'b.csv',['query_id','record_id','score'],[dict(query_id='q',record_id='a',score=0)])
        with self.assertRaises(ValueError):compare(temp/'j.csv',temp/'a.csv',temp/'b.csv',1)

suite=unittest.defaultTestLoader.loadTestsFromTestCase(Checks)
result=unittest.TextTestRunner(verbosity=2).run(suite)
status={'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'scope':'functional and data integrity checks; not model-quality evaluation'}
(ROOT/'Validation_Results.json').write_text(json.dumps(status,indent=2),encoding='utf-8')
if not result.wasSuccessful():sys.exit(1)

scenarios=[('cairo_icons','أيقونات عمارة كنيسة',(30.0444,31.2357),30),('wadi_manuscripts','مخطوطات دير',(30.30,30.40),40),('sohag_art','رسوم جدارية فن قبطي',(26.55,31.69),40)]
demo=[]
for sid,query,origin,radius in scenarios:
    nearest=rec.recommend(query,origin=origin,max_distance_km=radius,limit=3,weights={'content':0,'distance':1,'collaborative':0})
    hybrid=rec.recommend(query,origin=origin,max_distance_km=radius,limit=3)
    def path_length(items):
        pos=origin;total=0
        for item in items:
            row=next(r for r in rows if r['record_id']==item['record_id'])
            nxt=float(row['lat']),float(row['lon']);total+=distance_km(*pos,*nxt);pos=nxt
        return round(total,3)
    demo.append(dict(scenario_id=sid,query=query,origin=origin,radius_km=radius,nearest_only=nearest,content_plus_distance=hybrid,top3_overlap=len({x['record_id'] for x in nearest}&{x['record_id'] for x in hybrid}),nearest_rank_order_straight_line_km=path_length(nearest),hybrid_rank_order_straight_line_km=path_length(hybrid),interpretation='Illustrative offline ranking impact only; order is not route-optimized and distances are not road routes. No opening-hour, cost, duration or user satisfaction claims.'))
(ROOT/'Offline_Ranking_Scenarios.json').write_text(json.dumps(demo,ensure_ascii=False,indent=2),encoding='utf-8')
(ROOT/'Model_Comparison_Status.json').write_text(json.dumps(compare(ROOT/'Relevance_Judgments.csv',ROOT/'Christian_Predictions.csv',ROOT/'Islamic_Predictions.csv'),indent=2),encoding='utf-8')
print(json.dumps(status));print([(d['scenario_id'],d['top3_overlap']) for d in demo])
