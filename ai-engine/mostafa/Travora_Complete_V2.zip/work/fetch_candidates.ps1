$ErrorActionPreference='Stop'
$base=(Get-Location).Path
$ids=Get-ChildItem work/search/*.json | ForEach-Object {
    $d=Get-Content -LiteralPath $_.FullName -Raw | ConvertFrom-Json
    if ($d.search) { $d.search.id }
} | Sort-Object -Unique
$ids | ForEach-Object -Parallel {
    $id=$_
    $file=Join-Path $using:base "work/entities/$id.json"
    if (Test-Path -LiteralPath $file) {return}
    try {
        $r=Invoke-WebRequest -Uri "https://www.wikidata.org/wiki/Special:EntityData/$id.json" -TimeoutSec 20 -Headers @{'User-Agent'='TravoraDataValidation/1.0'}
        [System.IO.File]::WriteAllText($file,$r.Content,[System.Text.UTF8Encoding]::new($false))
    } catch { Write-Output "$id fetch failed: $($_.Exception.Message)" }
} -ThrottleLimit 3
"Candidate entities: $($ids.Count)"
