import csv,math,json,re,unicodedata
from collections import Counter
from pathlib import Path
base=Path('outputs')
dest=base/'Travora_Test'
dest.mkdir(exist_ok=True)
def read(name):
 with (base/name).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
rows=read('Egypt_Religious_Tourism_Merged_Scored.csv')
reference=read('Christian_Sites_Enriched_Labeled.csv')
islam=[r for r in rows if r['religion']=='Islam']
christ=[r for r in rows if r['religion']=='Christianity']
def tokens(row):
 c=Counter()
 for s in (row['name'],row['name_en'],row['amenity']):
  s=re.sub('[أإآ]','ا',unicodedata.normalize('NFKC',s).casefold())
  for w in re.findall(r'[^\W_]+',re.sub('[ـً-ْ]','',s)):
   c[w]+=1;p='^'+w+'$';c.update('tri:'+p[i:i+3] for i in range(len(p)-2))
 return c
def norm(v):
 n=math.sqrt(sum(x*x for x in v.values())) or 1
 return {t:x/n for t,x in v.items()}
texts=[tokens(r) for r in reference]
for r in christ:
 if r['record_id']:continue
 # Freeze the original reference catalogue; withhold nearby possible aliases of the site being scored.
 train=[i for i,s in enumerate(reference) if 111*math.hypot(float(s['lat'])-float(r['latitude']),(float(s['lon'])-float(r['longitude']))*math.cos(math.radians(float(r['latitude']))))>1]
 df=Counter(t for i in train for t in texts[i])
 idf={t:1+math.log((1+len(train))/(1+n)) for t,n in df.items()}
 def vec(c):return norm({t:(1+math.log(n))*idf[t] for t,n in c.items() if t in idf})
 profile=Counter()
 for i in train:
  if reference[i]['heritage_label']=='documented_significance':profile.update(vec(texts[i]))
 v=vec(tokens(dict(name=r['site_name'],name_en=r['name_en'],amenity='monastery' if r['site_type']=='Monastery' else 'place_of_worship')))
 r['ml_importance']=round(sum(x*v.get(t,0) for t,x in norm(profile).items()),8)
 r['ml_score_method']='positive_centroid_reference_excluding_1km'
 r['heritage_label']='unassessed'
 r['visit_access_status']='not_verified'
audit={x['record_id']:x for x in read('Christian_Merge_Audit.csv')}
for group,filename in [(christ,'Christianity'),(islam,'Islam')]:
 group.sort(key=lambda r:(-float(r['ml_importance']),r['site_id']))
 for i,r in enumerate(group,1):
  assert math.isfinite(float(r['ml_importance']))
  r['within_model_rank']=i
  if filename=='Christianity':
   r['christian_rank']=i
   flags=[]
   if r['recommendation_readiness'].startswith('hold'):flags.append(r['recommendation_readiness'])
   if audit.get(r['record_id'],{}).get('nearby_old_candidates'):flags.append('nearby_catalogue_record')
   if re.search('لرعاية الايتام|مدرسة|مقابر',r['site_name']):flags.append('non_tourism_name_review')
   r['review_flags']=';'.join(flags)
 with (dest/(filename+'.csv')).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(group[0]));w.writeheader();w.writerows(group)
def item(r):
 return [r['site_id'],r['site_name'],r['name_en'],r['region'],float(r['ml_importance']),r['within_model_rank'],r.get('review_flags',''),r['evidence_url'],r['fee_egyptian_egp'],r['fee_foreign_egp'],r['latitude'],r['longitude'],r['site_type'],r['heritage_label']]
payload=json.dumps({'Islam':list(map(item,islam)),'Christianity':list(map(item,christ))},ensure_ascii=False).replace('<','\\u003c')
(dest/'Travora.html').write_text(Path('work/ui.html').read_text(encoding='utf-8').replace('/*DATA*/',payload),encoding='utf-8')
assert len(islam)==584 and len(christ)==348
