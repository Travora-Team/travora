from pathlib import Path
import csv,json,re
base=Path('outputs/Travora_Test')
def read(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def save(p,rows):
 with p.open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(dict.fromkeys(k for r in rows for k in r)));w.writeheader();w.writerows(rows)
evidence={
'ADD_001':('https://sis.gov.eg/en/egypt/tourism/religious-tourism/al-azhar-mosque/','توثق الهيئة العامة للاستعلامات تاريخ الجامع الأزهر ومراحل تجديده.'),
'ADD_005':('https://egymonuments.gov.eg/en/monuments/the-mosque-of-amr-ibn-al-as/','تدرج الوزارة جامع عمرو بن العاص ضمن آثار مصر الإسلامية المبكرة.'),
'ADD_008':('https://egymonuments.gov.eg/en/monuments/mosque-of-al-hakim-bi-amr-allah','جامع تاريخي توثق الوزارة مكانته بين جوامع القاهرة المبكرة.'),
'ADD_009':('https://egymonuments.gov.eg/ar/monuments/al-aqmar-mosque/','جامع فاطمي أنشئ عام 1125م، وتتميز واجهته الحجرية بزخارف وكتابات كوفية.'),
'ICONIC_001':('https://egymonuments.gov.eg/en/monuments/mosque-and-madrasa-of-sultan-hasan','مجمع مملوكي يجمع المسجد والمدرسة، أمر السلطان حسن بإنشائه في القرن الرابع عشر.'),
'ICONIC_002':('https://egymonuments.gov.eg/monuments/al-rifa-i-mosque/','تضم عمارة المسجد قسمًا للصلاة ومدافن لأسرة محمد علي.'),
'ICONIC_004':('https://cairo.gov.eg/en/tourism/tourism-destinations/cultural/tourist-attractions/','تدرج محافظة القاهرة جامع أحمد بن طولون ضمن معالمها التاريخية وتذكر ترتيبه بين جوامع مصر المبكرة.')}
aliases={'MON_019':'CHR-0082','MON_026':'CHR-0082','MON_027':'CHR-0082','OSM_4530991990':'MON_116','MON_007':'CHR-0088','MON_008':'CHR-0088','MON_054':'CHR-0084'}
locations={'CHR-0082':'https://commons.wikimedia.org/wiki/File:Bischoy_Kloster_BW_1.jpg','CHR-0030':'https://en.wikipedia.org/wiki/Saint_Mercurius_Church_in_Coptic_Cairo'}
distinct=set('0137 0138 0150 0068 0016 0132 0006 0005 0017 0122 0143 0142 0003 0075 0145 0035 0133 0022'.split())
aud={r['record_id']:r['nearby_old_candidates'] for r in read(Path('outputs/Christian_Merge_Audit.csv'))}
data={};report=[]
for faith in ('Christianity','Islam'):
 rows=read(base/(faith+'.csv')); by={r['site_id']:r for r in rows}
 for r in rows:
  sid=r['site_id'];rid=r['record_id'];reason=[];decision='';source='';canonical=aliases.get(sid,'')
  if canonical:
   assert canonical in by
   decision='اسم بديل للمجمع نفسه في كتالوج الزيارات؛ جُمّع مع '+canonical
  else:
   if r['needs_review'].lower()=='true' and (r['is_generic_name'].lower()=='true' or faith=='Islam'):reason.append('الاسم المسجل عام ويحتاج تحديد هوية المكان')
   if float(r['coord_shift_vs_prior_m'] or 0)>250:reason.append('تغيّر موضع السجل عن النسخة السابقة بمقدار '+r['coord_shift_vs_prior_m']+' متر')
   if r.get('review_flags','').find('non_tourism')>=0:reason.append('يلزم التأكد من أن المكان مزار متاح للزيارة')
   if rid in locations:
    decision='اعتماد نقطة السجل للمجمع بعد مقارنتها بإحداثيات منشورة قريبة؛ نقطة الدخول غير متحققة';source=locations[rid]
   elif r['coordinate_review_status']=='cross_source_discrepancy_over_250m':
    reason.append('اختلاف الإحداثيات عن Wikidata بمقدار '+r['coordinate_delta_m']+' متر');source=r['wikidata_url']
   if rid=='CHR-0085':
    decision='معرّف Wikidata يخص القرية؛ استُبعد من ربط الدير';r['wikidata']='';r['wikidata_entity_id']='';r['wikidata_link_status']='rejected_village_entity'
   if rid=='CHR-0103':reason.append('قد يشير الاسم إلى دير السريان بينما النقطة قريبة من دير بيشوي؛ لا يُعتمد الموضع بعد')
   if rid.split('-')[-1] in distinct:
    decision='يشير اسم السجل واسم الجار إلى مبنيين مختلفين؛ أزيل تعليق القرب'
   elif aud.get(rid) and rid not in ('CHR-0082','CHR-0088','CHR-0084'):
    reason.append('مطابقة محتملة مع '+aud[rid])
   if rid=='CHR-0084':reason.append('سجل أبو خشبة يشارك إحداثيات دير الملاك؛ يلزم تثبيت موضع المبنيين')
  if sid in evidence:
   r['evidence_url'],r['evidence_claim']=evidence[sid];r['heritage_label']='documented_significance';r['evidence_accessed_on']='2026-11-16'
  elif not r['heritage_label']:r['heritage_label']='unassessed'
  r['canonical_site_id']=canonical or sid;r['review_reason_ar']=' · '.join(reason);r['identity_decision_ar']=decision;r['location_review_source']=source
  r['review_flags']=';'.join(reason);r['catalogue_status']='alias' if canonical else 'hold' if reason else 'listed'
  if decision or reason or sid in evidence:report.append(dict(religion=faith,site_id=sid,canonical=r['canonical_site_id'],status=r['catalogue_status'],decision=decision,reason=r['review_reason_ar'],source=source or r['evidence_url']))
 save(base/(faith+'.csv'),rows)
 active=[r for r in rows if r['catalogue_status']!='alias']
 data[faith]=[[r['site_id'],r['site_name'],r['name_en'],r['region'],float(r['ml_importance']),r['within_model_rank'],r['review_reason_ar'],r['evidence_url'],r['fee_egyptian_egp'],r['fee_foreign_egp'],r['latitude'],r['longitude'],r['site_type'],r['heritage_label'],r['evidence_claim'],r['identity_decision_ar'],r['location_review_source']] for r in active]
 print(faith,len(active),sum(bool(r[6]) for r in data[faith]),sum(r[13]=='documented_significance' for r in data[faith]))
save(base/'Review_Audit.csv',report)
ui=Path('work/ui.html').read_text(encoding='utf-8-sig').replace("el('reviewLabel').hidden=el('docLabel').hidden=m==='Islam';","").replace("+(r[7].startsWith", "+(r[6]?'<p>'+esc(r[6])+'</p>':'')+(r[15]?'<p>'+esc(r[15])+'</p>':'')+(r[16].startsWith('https://')?'<a target=\"_blank\" rel=\"noopener\" href=\"'+esc(r[16])+'\">مرجع مراجعة الموقع</a>':'')+(r[14]?'<p>'+esc(r[14])+'</p>':'')+(r[7].startsWith")
(base/'Travora.html').write_text(ui.replace('/*DATA*/',json.dumps(data,ensure_ascii=False).replace('<','\\u003c')),encoding='utf-8')
