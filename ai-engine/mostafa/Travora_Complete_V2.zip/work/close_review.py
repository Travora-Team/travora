from pathlib import Path
import csv,json,re,math
D=Path('outputs/Travora_Test')
W=Path('work')
def read(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(p,rows):
 with p.open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(dict.fromkeys(k for r in rows for k in r)));w.writeheader();w.writerows(rows)
def js(name):return json.loads((W/name).read_text(encoding='utf-8-sig'))
ways={f"way/{x['id']}":x for x in js('closure_way.json')['elements']}
coords={x['id']:(x['lon'],x['lat']) for x in js('closure_geometry.json')}
generic={f"OSM_{x['id']}":x for x in js('closure_osm.json')['elements']}
def inside(pt,poly):
 x,y=pt;hit=False
 for (a,b),(c,d) in zip(poly,poly[1:]):
  if (b>y)!=(d>y) and x<(c-a)*(y-b)/(d-b)+a:hit=not hit
 return hit
audit=[];visible={};allout=[]
for faith in ['Islam','Christianity']:
 rows=read(D/(faith+'.csv'));by={r['site_id']:r for r in rows}
 for r in rows:
  sid=r['site_id']; old=r['catalogue_status']
  if old!='hold' and sid not in ('MON_042','MON_072','MON_077'):continue
  status='excluded';reason='تعذّر حسم موضع الزيارة أو مطابقة هوية السجل؛ استُبعد من كتالوج العرض.';url='';target=''
  if sid in generic:
   url='https://www.openstreetmap.org/node/'+sid[4:];reason='فُحص سجل OSM الحالي؛ الاسم عام أو فارغ ولا يميز مزارًا بعينه.'
  elif sid=='ADD_013':
   status='listed';reason='تطابق الاسم والمدينة والنقطة الحالية مع موقع المسجد المنشور بفارق يقارب 33 مترًا.';url='https://en.wikipedia.org/wiki/Ibrahim_El_Desouki_Mosque'
  elif sid=='CHR-0028':
   status='listed';reason='صورة برج كاتدرائية الملاك ميخائيل بأسوان بإحداثيات قريبة من المبنى تؤيد الاسم الإنجليزي والنقطة.';url='https://commons.wikimedia.org/wiki/File:St_Michael%27s_Coptic_Cathedral_-_Aswan_01.JPG';r['site_name']='كاتدرائية الملاك ميخائيل بأسوان'
  elif sid in ('OSM_8553739963','CHR-0049','CHR-0050'):
   reason='اسم السجل يصف دار رعاية أو قطعة أرض، ولا يثبت وجود مزار محدد.';url='https://www.openstreetmap.org/'+(r['osm_id'] or 'node/'+sid[4:])
  elif r['osm_id'] in ways:
   obj=ways[r['osm_id']];poly=[coords[i] for i in obj['nodes']];url='https://www.openstreetmap.org/'+r['osm_id']
   ids=re.findall(r'(?:MON_|OSM_|ICONIC_)\d+',r['review_reason_ar'])
   hits=[i for i in ids if i in by and inside((float(by[i]['longitude']),float(by[i]['latitude'])),poly)]
   if sid in ('CHR-0103','CHR-0139','CHR-0195'):
    target={'CHR-0103':'MON_108','CHR-0139':'MON_130','CHR-0195':'MON_111'}[sid]
    status='alias';reason='تمثيل واحد للمجمع في نتائج الرحلات، مع حفظ المبنى أو النقطة الفرعية في الأرشيف.'
   elif sid=='CHR-0172' and 'OSM_14143459351' in hits:
    status='alias';target='OSM_14143459351';reason='نقطة كنيسة العذراء داخل حدود مبنى الكنيسة المسجّل بالاسم نفسه.'
   elif sid in ('CHR-0053','CHR-0104','CHR-0152','CHR-0113','CHR-0106','CHR-0057','CHR-0069','CHR-0102','CHR-0161','CHR-0128','CHR-0147','CHR-0021') and not hits:
    status='listed';reason='اسم المبنى يختلف عن المرشحين المجاورين، ونقاطهم خارج حدوده المرسومة في OSM.'
   elif hits:reason='تداخل مكاني مع '+', '.join(hits)+'؛ لا يكفي التداخل وحده لإثبات تطابق المبنى.'
  elif sid=='CHR-0195':
   target='MON_111';status='alias';reason='عرض مجمع جبل الطير مرة واحدة على مستوى الوجهة، دون اعتبار النقطتين مبنى واحدًا.';url='https://sis.gov.eg/en/media-center/news/tourism-minister-minya-governor-inspect-virgin-mary-church-in-gabal-el-tayr/'
  else:
   url=r['location_review_source'] or (('https://www.openstreetmap.org/'+r['osm_id']) if r['osm_id'] else '')
  if sid in ('MON_042','MON_072','MON_077'):reason='نقطة قديمة مشتركة مع أسماء أخرى لم يُحسم موضعها المستقل.'
  r['previous_review_reason']=r['review_reason_ar'];r.update(catalogue_status=status,review_flags='',review_reason_ar='',identity_decision_ar=reason,location_review_source=url,canonical_site_id=target or sid)
  audit.append(dict(site_id=sid,religion=faith,previous_status=old,decision=status,canonical=target,reason=reason,source=url))
 active=[r for r in rows if r['catalogue_status']=='listed'];archive=[r for r in rows if r['catalogue_status']!='listed']
 for i,r in enumerate(active,1):
  r['within_model_rank']=i;r['needs_review']='False'
  if faith=='Christianity':r['christian_rank']=i
  if r.get('recommendation_readiness','').startswith('hold'):r['recommendation_readiness']='offline_candidate_access_unverified'
 write(W/(faith+'_closed.csv'),active);write(W/(faith+'_archived.csv'),archive)
 visible[faith]=[[r['site_id'],r['site_name'],r['name_en'],r['region'],float(r['ml_importance']),r['within_model_rank'],'',r['evidence_url'],r['fee_egyptian_egp'],r['fee_foreign_egp'],r['latitude'],r['longitude'],r['site_type'],r['heritage_label'],r['evidence_claim'],r['identity_decision_ar'],r['location_review_source']] for r in active]
 allout+=archive
 print(faith,len(active),len(archive))
write(D/'Excluded_and_Alias_Records.csv',allout);write(D/'Final_Decisions.csv',audit)
for faith in visible:(W/(faith+'_closed.csv')).replace(D/(faith+'.csv'))
ui=(D/'Travora.html').read_text(encoding='utf-8')
ui=re.sub(r'const data=.*?;\s*const el=',lambda m:'const data='+json.dumps(visible,ensure_ascii=False).replace('<','\\u003c')+';\nconst el=',ui,flags=re.S)
ui=re.sub('<label id="reviewLabel">.*?</label>','',ui)
ui=ui.replace("el('held').checked=false;","").replace("&&(!r[6]||el('held').checked)","").replace("'reg','held','doc'","'reg','doc'")
(D/'Travora.html').write_text(ui,encoding='utf-8')
from collections import Counter
print(Counter(r['decision'] for r in audit if r['previous_status']=='hold'))
