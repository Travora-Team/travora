$ErrorActionPreference = 'Stop'
New-Item -ItemType Directory -Force -Path work/entities | Out-Null
$rows = Import-Csv outputs/Christian_Sites_Cleaned_Review.csv
$ids = $rows.wikidata -split ';' | Where-Object { $_ -match '^Q[1-9][0-9]*$' } | Sort-Object -Unique
$log = foreach ($id in $ids) {
    $file = "work/entities/$id.json"
    try {
        if (!(Test-Path -LiteralPath $file)) {
            $r = Invoke-WebRequest -Uri "https://www.wikidata.org/wiki/Special:EntityData/$id.json" -Headers @{'User-Agent'='TravoraDataValidation/1.0'} -TimeoutSec 20
            [System.IO.File]::WriteAllText((Join-Path (Get-Location) $file), $r.Content, [System.Text.UTF8Encoding]::new($false))
        }
        [pscustomobject]@{id=$id;status='fetched';url="https://www.wikidata.org/wiki/$id"}
    } catch { [pscustomobject]@{id=$id;status=$_.Exception.Message;url="https://www.wikidata.org/wiki/$id"} }
}
$log | Export-Csv work/wikidata_fetch_log.csv -NoTypeInformation -Encoding utf8
$log | Group-Object status | Select-Object Name,Count | ConvertTo-Json
