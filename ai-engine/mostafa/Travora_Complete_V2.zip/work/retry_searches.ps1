$ErrorActionPreference='Stop'
$retry=Get-ChildItem work/search/*.json | Where-Object { (Get-Content -LiteralPath $_.FullName -Raw | ConvertFrom-Json).error }
$done=0
foreach ($file in $retry) {
    $d=Get-Content -LiteralPath $file.FullName -Raw | ConvertFrom-Json
    try {
        $r=Invoke-WebRequest -Uri $d.url -TimeoutSec 20 -Headers @{'User-Agent'='TravoraDataValidation/1.0'}
        [System.IO.File]::WriteAllText($file.FullName,$r.Content,[System.Text.UTF8Encoding]::new($false))
        $done++
    } catch {
        if ($_.Exception.Message -match '429') { "Rate limit persists; stopped after $done successful retries."; break }
        "Fetch failed for $($file.BaseName): $($_.Exception.Message)"
    }
    Start-Sleep -Milliseconds 1500
}
"Successful retries: $done"
