$ErrorActionPreference='Stop'
New-Item -ItemType Directory -Force -Path work/search | Out-Null
$base=(Get-Location).Path
$rows=Import-Csv outputs/Christian_Sites_Cleaned_Review.csv | Where-Object { !$_.wikidata -or $_.record_id -eq 'CHR-0014' }
$rows | ForEach-Object -Parallel {
    $r=$_
    $file=Join-Path $using:base "work/search/$($r.record_id).json"
    if (Test-Path -LiteralPath $file) { return }
    $query=$r.name_en
    $lang=if ($query -match '[A-Za-z]') {'en'} else {'ar'}
    $uri='https://www.wikidata.org/w/api.php?action=wbsearchentities&language='+$lang+'&uselang=en&format=json&limit=3&search='+[Uri]::EscapeDataString($query)
    try {
        $res=Invoke-WebRequest -Uri $uri -TimeoutSec 20 -Headers @{'User-Agent'='TravoraDataValidation/1.0'}
        [System.IO.File]::WriteAllText($file,$res.Content,[System.Text.UTF8Encoding]::new($false))
    } catch {
        [System.IO.File]::WriteAllText($file,(@{error=$_.Exception.Message;query=$query;url=$uri}|ConvertTo-Json),[System.Text.UTF8Encoding]::new($false))
    }
} -ThrottleLimit 3
Get-ChildItem work/search | Measure-Object | Select-Object Count | ConvertTo-Json
