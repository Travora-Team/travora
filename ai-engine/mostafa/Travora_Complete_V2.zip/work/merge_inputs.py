from pathlib import Path
import csv, math
def read(p): return list(csv.DictReader(p.open(encoding="utf-8-sig",newline="")))
old=read(next((Path.home()/"AppData/Local/Packages").glob("5319275A.WhatsAppDesktop*/LocalState/sessions/*/transfers/2026-46/Egypt_Religious_Tourism_Scored.csv")))
new=read(Path("outputs/Christian_Sites_ML_Scored.csv"))
def dist(a,b): return 111200*math.hypot(float(a["latitude"])-float(b["latitude"]),math.cos(math.radians(float(a["latitude"])))*(float(a["longitude"])-float(b["longitude"])))
def near(n): return sorted((dist(n,o),o["site_id"],o["site_name"]) for o in old if o["religion"]=="Christianity")
if __name__=="__main__":
 for n in new:
  d,i,s=near(n)[0]
  if i!="OSM_"+n["osm_id"].split("/")[-1] and d<600:print(n["record_id"],n["name_en"],i,s,round(d))
