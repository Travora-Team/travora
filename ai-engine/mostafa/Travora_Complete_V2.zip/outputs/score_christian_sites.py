"""Fit a positive-example text profile and score sites without their own identity group."""
import csv
import json
import math
import re
import unicodedata
from collections import Counter
from pathlib import Path

base = Path(__file__).resolve().parent
with (base / "Christian_Sites_Enriched_Labeled.csv").open(encoding="utf-8-sig", newline="") as stream:
    sites = list(csv.DictReader(stream))

def features(site):
    features = Counter()
    for field in ("name", "name_en", "amenity"):
        value = unicodedata.normalize("NFKC", site[field]).casefold()
        value = re.sub("[أإآ]", "ا", value)
        value = re.sub("[ـً-ْ]", "", value)
        for word in re.findall(r"[^\W_]+", value):
            features[word] += 1
            padded = "^" + word + "$"
            features.update("tri:" + padded[i:i+3] for i in range(len(padded)-2))
    return features

def normalize(vector):
    length = math.sqrt(sum(value**2 for value in vector.values())) or 1
    return {key: value / length for key, value in vector.items()}

texts = [features(site) for site in sites]
groups = [site["leakage_group"] for site in sites]
positive = [site["heritage_label"] == "documented_significance" for site in sites]
scores = [None] * len(sites)
for group in sorted(set(groups)):
    train = [i for i, other in enumerate(groups) if other != group]
    frequencies = Counter(term for i in train for term in texts[i].keys())
    idf = {term: 1 + math.log((1 + len(train))/(1 + count)) for term, count in frequencies.items()}
    def vector(i):
        return normalize({term: (1 + math.log(count))*idf[term] for term, count in texts[i].items() if term in idf})
    center = Counter()
    for i in train:
        if positive[i]:
            center.update(vector(i))
    if not center:
        raise ValueError("No documented example outside this group")
    profile = normalize(center)
    for i, other in enumerate(groups):
        if other == group:
            scores[i] = sum(value * profile.get(term, 0) for term, value in vector(i).items())

ranked = sorted(range(len(sites)), key=lambda i: (-scores[i], sites[i]["record_id"]))
records = []
for rank, i in enumerate(ranked, 1):
    site = sites[i]
    records.append(dict(site, site_id=site["record_id"], religion="Christianity",
                        latitude=site["lat"], longitude=site["lon"],
                        ml_importance=round(scores[i], 8), christian_rank=rank,
                        ml_label=1 if positive[i] else "",
                        ml_score_method="positive_centroid_group_holdout_cosine"))
path = base / "Christian_Sites_ML_Scored.csv"
with path.open("w", encoding="utf-8-sig", newline="") as stream:
    writer = csv.DictWriter(stream, fieldnames=list(records[0]))
    writer.writeheader()
    writer.writerows(records)
with path.open(encoding="utf-8-sig", newline="") as stream:
    saved = list(csv.DictReader(stream))
assert len(saved) == len(set(r["site_id"] for r in saved)) == len(sites)
assert all(0 <= float(r["ml_importance"]) <= 1 for r in saved)
hits = sum(positive[i] for i in ranked[:20])
print(json.dumps(dict(records=len(saved), documented=sum(positive), held_out_documented_in_top20=hits,
                      expected_hits_random_top20=20*sum(positive)/len(saved))))
