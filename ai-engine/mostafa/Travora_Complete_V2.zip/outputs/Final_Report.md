# Travora religious tourism | Final delivery report

**14 November 2026 · 238 Christian site records · Offline prototype**

The Christian recommender runs locally. Of 238 records, 19 have a cited claim supporting historical, artistic or tourism significance. Sixteen of those pass the prototype’s location and identity filters. The supplied application supports Christianity and Islam, but its operating catalogue is missing from the delivery. A comparison of the two models and an integrated trip-planning result remain open.

## Work completed

| Stage | Result | What remains |
|---|---|---|
| Cleaning | The source contained 238 records, all named. No exact duplicate rows or explicit school/cemetery classifications were found. The first pass corrected 161 unsupported denomination mappings. | Resolve 34 possible duplicate pairs using site identity and maps. The pairs do not represent 34 confirmed duplicates. |
| Enrichment | Reviewed 38 Wikidata entities from the original IDs and linked 24 records to Wikipedia. Recorded claim, publisher, URL and match rationale for 19 sites. Corrected the Saint Anthony monastery link that pointed to a mountain. | Finish source research for 219 unassessed records. Wikidata rate limits left 182 additional searches incomplete. |
| Labels | Preserved documented significance and unassessed as distinct states. Kept UNESCO tentative entries distinct from inscribed properties. | Obtain independent relevance or significance judgments suitable for evaluation. The 219 unassessed sites have no negative label. |
| Model | Fitted and saved a bilingual TF-IDF content index using all 238 records. The ranker combines query similarity and distance and can accept external collaborative scores. | Real interaction scores and independently judged examples are needed to test personalization and train the proposed supervised classifier. |
| Validation | The Christian package recorded 13 passing functional checks. Three offline scenarios compared proximity-only and hybrid rankings. | Validate visitor access, cost, accessibility, opening hours and road travel before live itinerary use. Six records have coordinate disagreements above the chosen 250 m review threshold. |

## What changed in the offline trips

| Query area and interest | Hybrid result in rank order | Straight-line distance following ranking order, proximity-only → hybrid |
|---|---|---|
| Cairo, icons and church architecture | Hanging Church, Saint George’s Church, Saint Barbara Church | 4.379 → 4.662 km |
| Wadi El Natrun, manuscripts | Syrian Monastery, Saint Macarius, Paromeos | 37.810 → 37.810 km |
| Sohag, wall paintings and Coptic art | Red Monastery, White Monastery | 8.138 → 10.403 km |

The distances include travel from the scenario origin through the selected stops. Cairo’s hybrid ranking retained two of the three proximity-only selections. In Sohag it returned the same two sites in a different order. These examples measure selection and ordering under the prototype’s chosen weights. Visitor satisfaction, road travel time and comparative model accuracy remain unmeasured.

## Findings from models.zip

The archive contains the application entry point, the religious trip planner, a serialized scikit-learn pipeline and a compiled Python cache. Source inspection established the following integration requirements.

- The app prefers `Egypt_Religious_Tourism_Scored.csv` and otherwise opens `Egypt_Religious_Tourism_Muslim_Christian.csv`. Neither file was supplied. The planner reads scores from the catalogue’s `ml_importance` column. Placing the joblib file beside the app does not activate inference.
- The planner accepts both religions. The archive alone does not establish the training population of the serialized pipeline. The training script and model report referenced by the source are absent. The binary was inspected as data and inference was not run.
- The planner expects `Christianity`, `site_id`, `latitude`, `longitude`, `region`, visitor fee fields and other planning fields. The Christian output uses `christian`, `record_id`, `lat` and `lon`. Renaming fields covers only part of the mapping. Region, fees, access and stable catalogue identities still need a join.
- The planner uses a 1 km monastery deduplication rule. It can suppress distinct, nearby monasteries. Check the Wadi El Natrun cluster against confirmed identities before applying that rule. The Christian model returns query-specific similarity, whereas the app interprets `ml_importance` as a site-level score. Wire query similarity into ranking as a separate component.

## Work needed for release

1. Supply the scored mixed-faith catalogue the app used, or its unscored catalogue plus the feature-building/training script and compatible dependency versions. These are the next inputs needed to reproduce the supplied baseline.
2. Join the Christian records to stable planner IDs, confirm the held coordinates and duplicates, and populate visitor data with sourced values. Record unknown fees and access explicitly.
3. Connect the Christian ranker to the supplied planner and exercise its normal request path. Compare identical region, budget, visitor, day-count and interest settings before and after the change. Check duplicate stops, budget compliance and route feasibility.
4. Collect independent query–site relevance judgments. Evaluate both model variants on a common task and a comparable candidate pool. Report ranking quality alongside travel cost and coverage. If each model serves a different catalogue, report domain-specific results and document differences in the test sets.

The final ZIP includes this report, the supplied archive unchanged, and the Christian package with the enriched CSV, evidence ledger, pending review list, fitted model and operating instructions. The earlier Arabic documentation inside that package describes the state before the supplied application arrived. This report updates the application and model inventory.
