"""Train only after explicit human gold labels exist. Unknown is never negative."""
import argparse,csv,json
from collections import Counter
from pathlib import Path

def run(data_path,gold_path,output_dir):
    out=Path(output_dir);out.mkdir(parents=True,exist_ok=True)
    data=list(csv.DictReader(Path(data_path).open(encoding='utf-8-sig',newline='')))
    gold=list(csv.DictReader(Path(gold_path).open(encoding='utf-8-sig',newline='')))
    lookup={r['record_id']:r for r in data}
    labeled=[];seen=set()
    for r in gold:
        if r.get('gold_label','')=='':continue
        if r['record_id'] not in lookup or r['record_id'] in seen:raise ValueError('Unknown or duplicate adjudicated ID.')
        if r['gold_label'] not in ('0','1') or not r.get('reviewer') or not r.get('rationale') or not r.get('review_date'):raise ValueError('Gold label requires 0/1, reviewer, date and rationale.')
        if r['gold_label']=='0' and r.get('rationale','').strip().lower() in ('no wikidata','unknown','unassessed','no documentation'):raise ValueError('Missing documentation is not a negative label.')
        seen.add(r['record_id']);labeled.append((lookup[r['record_id']],int(r['gold_label'])))
    counts=Counter(y for _,y in labeled)
    groups={y:{r['leakage_group'] for r,t in labeled if t==y} for y in (0,1)}
    base={'gold_records':len(labeled),'class_counts':dict(counts),'group_counts':{str(y):len(v) for y,v in groups.items()},'unknown_rows_excluded':len(data)-len(labeled)}
    if any(len(groups[y])<5 for y in (0,1)):
        result=dict(base,status='not_trained',reason='Need both adjudicated classes and at least five leakage groups per class as a minimum engineering gate; this is not a statistical sample-size guarantee.')
        (out/'supervised_training_status.json').write_text(json.dumps(result,indent=2),encoding='utf-8');return result
    # These optional dependencies are imported only after the data gate passes.
    import joblib
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.linear_model import LogisticRegression
    from sklearn.metrics import average_precision_score,balanced_accuracy_score,roc_auc_score
    from sklearn.model_selection import GroupShuffleSplit
    from sklearn.pipeline import make_pipeline
    X=[' '.join(r[k] for k in ('name','name_en','site_type')) for r,_ in labeled]
    y=[v for _,v in labeled];g=[r['leakage_group'] for r,_ in labeled]
    split=None
    for train,test in GroupShuffleSplit(n_splits=100,test_size=0.25,random_state=42).split(X,y,g):
        if all(len({g[i] for i in fold if y[i]==c})>=2 for fold in (train,test) for c in (0,1)):
            split=train,test;break
    if split is None:raise ValueError('No valid group-disjoint holdout with both classes. Collect more adjudications.')
    train,test=split
    model=make_pipeline(TfidfVectorizer(analyzer='char_wb',ngram_range=(3,5)),LogisticRegression(class_weight='balanced',max_iter=2000,random_state=42))
    model.fit([X[i] for i in train],[y[i] for i in train])
    prob=model.predict_proba([X[i] for i in test])[:,1];truth=[y[i] for i in test]
    metrics={'average_precision':average_precision_score(truth,prob),'roc_auc':roc_auc_score(truth,prob),'balanced_accuracy_at_0_5':balanced_accuracy_score(truth,prob>=0.5)}
    joblib.dump(model,out/'christian_significance_holdout_model.joblib')
    result=dict(base,status='trained_with_group_holdout',metrics=metrics,train_ids=[labeled[i][0]['record_id'] for i in train],test_ids=[labeled[i][0]['record_id'] for i in test],limitations='Single exploratory holdout; no model-selection tuning or deployment-quality claim.')
    (out/'supervised_training_status.json').write_text(json.dumps(result,indent=2),encoding='utf-8');return result

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--data',default='Christian_Sites_Enriched_Labeled.csv');p.add_argument('--gold',default='Significance_Adjudication.csv');p.add_argument('--output-dir',default='.')
    a=p.parse_args();print(json.dumps(run(a.data,a.gold,a.output_dir),indent=2))
