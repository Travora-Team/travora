"""Compare two rankings on the exact same fully judged query-item universe."""
import argparse,csv,json,math
from collections import defaultdict
from pathlib import Path

def load(path):return list(csv.DictReader(Path(path).open(encoding='utf-8-sig',newline='')))
def compare(judgments_path,christian_path,islamic_path,k=5):
    if k<1:raise ValueError('k must be positive')
    qrels=defaultdict(dict)
    for r in load(judgments_path):
        if r.get('relevance','')=='':continue
        if r['record_id'] in qrels[r['query_id']]:raise ValueError('Duplicate judgment')
        grade=int(r['relevance'])
        if grade not in (0,1,2,3):raise ValueError('relevance must be 0..3')
        if not r.get('reviewer'):raise ValueError('Judgments require a reviewer')
        qrels[r['query_id']][r['record_id']]=grade
    if not qrels:return {'status':'not_evaluated','reason':'No independent relevance judgments; no metrics computed.'}
    universe={(q,i) for q,v in qrels.items() for i in v}
    results={}
    for name,path in [('christian',christian_path),('islamic',islamic_path)]:
        pred=defaultdict(dict)
        for r in load(path):
            key=(r['query_id'],r['record_id']);score=float(r['score'])
            if key not in universe or r['record_id'] in pred[r['query_id']] or not math.isfinite(score):raise ValueError('Invalid, duplicate or unjudged prediction')
            pred[r['query_id']][r['record_id']]=score
        if {(q,i) for q,v in pred.items() for i in v}!=universe:raise ValueError('Both models must score the entire same judged pool.')
        scores=[]
        for q,rels in qrels.items():
            ranked=sorted(pred[q],key=lambda i:(-pred[q][i],i))[:k]
            gain=lambda g:(2**g-1)
            dcg=sum(gain(rels[i])/math.log2(n+2) for n,i in enumerate(ranked))
            ideal=sum(gain(g)/math.log2(n+2) for n,g in enumerate(sorted(rels.values(),reverse=True)[:k]))
            positives=sum(g>0 for g in rels.values())
            scores.append({'query_id':q,'ndcg_at_k':dcg/ideal if ideal else None,'recall_at_k':sum(rels[i]>0 for i in ranked)/positives if positives else None})
        valid=[v for v in scores if v['ndcg_at_k'] is not None]
        results[name]={'queries':len(scores),'queries_with_positive_judgments':len(valid),'macro_ndcg_at_k':sum(v['ndcg_at_k'] for v in valid)/len(valid) if valid else None,'macro_recall_at_k':sum(v['recall_at_k'] for v in valid)/len(valid) if valid else None,'per_query':scores}
    return {'status':'evaluated','k':k,'dcg_gain':'2^relevance-1','results':results,'limitations':'Shared fixed judged pool; no confidence interval or causal product impact implied.'}

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--judgments',required=True);p.add_argument('--christian',required=True);p.add_argument('--islamic',required=True);p.add_argument('--k',type=int,default=5)
    a=p.parse_args();print(json.dumps(compare(a.judgments,a.christian,a.islamic,a.k),indent=2))
