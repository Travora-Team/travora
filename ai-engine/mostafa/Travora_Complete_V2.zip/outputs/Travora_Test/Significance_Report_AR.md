# مراجعة دليل الأهمية في كتالوج Travora

تاريخ الفحص 16 نوفمبر 2026. فُحصت حالة التوثيق لكل السجلات المعروضة، واختيرت مواقع من رتب مختلفة لمطابقتها بمصادر خارجية. يغطي التقرير الإضافات المؤكدة في هذه الجولة. درجات الترتيب من النموذجين السابقين.

## المواقع الإسلامية

- مشهد الإمام الشافعي (الترتيب 6، المعرّف `ADD_006`). يوثّق مركز البحوث الأمريكي بمصر القيمة الفنية والتاريخية لمشهد الإمام الشافعي وأعمال الحفاظ عليه. [المصدر](https://arce.org/project/al-imam-al-shafii-conservation-project/)

- مجموعة السلطان قلاوون (الترتيب 7، المعرّف `ADD_007`). تجمع مجموعة قلاوون بشارع المعز بين المسجد والمدرسة والضريح والبيمارستان. [المصدر](https://egymonuments.gov.eg/en/monuments/madrasa-mausaleum-and-bimaristan-of-al-mansur-qalawun)

- جامع المؤيد شيخ (الترتيب 10، المعرّف `ADD_010`). استُخدم برجا باب زويلة قاعدتين لمئذنتي جامع السلطان المؤيد شيخ. [المصدر](https://egymonuments.gov.eg/en/monuments/al-muayyad-sheikh-mosque)

- جامع محمد علي (الترتيب 16، المعرّف `ICONIC_003`). توثق وزارة السياحة والآثار جامع محمد علي داخل قلعة صلاح الدين بالقاهرة. [المصدر](https://egymonuments.gov.eg/en/monuments/muhammad-ali-mosque/)

- مدرسة وخانقاة السلطان برقوق (الترتيب 18، المعرّف `OSMR_16821945`). أنشأ السلطان برقوق المدرسة والخانقاه بشارع المعز بين عامي 1384 و1386. [المصدر](https://egymonuments.gov.eg/monuments/madrasa-and-khanaqah-of-sultan-al-zahir-barquq/)

- مسجد سليمان باشا الخادم (الترتيب 19، المعرّف `OSMR_16841663`). يوثق سجل الآثار مسجد سليمان باشا الخادم بقلعة القاهرة ونسبته إلى الوالي العثماني. [المصدر](https://egymonuments.gov.eg/en/monuments/mosque-of-sulayman-pasha-al-khadim-saraya-al-jabal-mosque)

- جامع الناصر محمد بن قلاوون (الترتيب 23، المعرّف `OSMR_446129`). كان جامع الناصر محمد بن قلاوون بالقلعة المسجد السلطاني في العصر المملوكي. [المصدر](https://egymonuments.gov.eg/monuments/sultan-al-nasir-muhammad-mosque/)

- جامع السلطان الظاهر بيبرس (الترتيب 36، المعرّف `OSMW_28848324`). أمر السلطان بيبرس ببناء الجامع في ميدان الظاهر سنة 1266. [المصدر](https://egymonuments.gov.eg/monuments/mosque-of-al-zahir-baybars/)

- المسجد الأزرق (الترتيب 37، المعرّف `OSMW_29973707`). يوثق صندوق الآغا خان للثقافة ترميم مسجد آق سنقر المعروف بالمسجد الأزرق، ويرجع بناؤه إلى القرن الرابع عشر. [المصدر](https://the.akdn/en/resources-media/whats-new/news-release/blue-mosque-cairo-restored-aga-khan-trust-culture)

- مسجد الفتاح العليم (الترتيب 46، المعرّف `OSMW_853062557`). توثق رئاسة الجمهورية افتتاح مسجد الفتاح العليم بالعاصمة الإدارية في احتفال رسمي. [المصدر](https://www.presidency.eg/FR/%D9%82%D8%B3%D9%85-%D8%A7%D9%84%D8%A3%D8%AE%D8%A8%D8%A7%D8%B1/%D8%A3%D8%AE%D8%A8%D8%A7%D8%B1-%D8%B1%D8%A6%D8%A7%D8%B3%D9%8A%D8%A9/%D8%A7%D9%84%D8%B3%D9%8A%D8%AF-%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3-%D9%8A%D9%81%D8%AA%D8%AA%D8%AD-%D9%85%D8%B3%D8%AC%D8%AF-%D8%A7%D9%84%D9%81%D8%AA%D8%A7%D8%AD-%D8%A7%D9%84%D8%B9%D9%84%D9%8A%D9%85-%D9%88%D9%83%D8%A7%D8%AA%D8%AF%D8%B1%D8%A7%D8%A6%D9%8A%D8%A9-%D9%85%D9%8A%D9%84%D8%A7%D8%AF-%D8%A7%D9%84%D9%85%D8%B3%D9%8A%D8%AD-%D8%A8%D8%A7%D9%84%D8%B9%D8%A7%D8%B5%D9%85%D8%A9-%D8%A7%D9%84%D8%A5%D8%AF%D8%A7%D8%B1%D9%8A%D8%A9-%D8%A7%D9%84%D8%AC%D8%AF%D9%8A%D8%AF%D8%A9-%D9%88%D9%8A%D8%B4%D8%A7%D8%B1%D9%83-%D9%81%D9%8A-%D9%82%D8%AF%D8%A7%D8%B3-%D8%B9%D9%8A%D8%AF-%D8%A7%D9%84%D9%85%D9%8A%D9%84%D8%A7%D8%AF-%D8%A7%D9%84%D9%85%D8%AC%D9%8A%D8%AF-%D8%A8%D8%A7%D9%84%D9%83%D8%A7%D8%AA%D8%AF%D8%B1%D8%A7%D8%A6%D9%8A%D8%A9/)

بعد التحديث يوجد دليل مسجل لـ 17 من 571 موقعًا. عدد المواقع دون دليل أهمية مسجل هو 554.

## المواقع المسيحية

- St Simon The Tanner - Deir Samaan al-Kharaz Cairo (الترتيب 10، المعرّف `MON_130`). تصف محافظة القاهرة عمارة دير سمعان الخراز وتدرجه ضمن معالم القاهرة الكنسية. [المصدر](https://cairo.gov.eg/en/culture/cairo-history/mosques-and-churches/cairo-churches/)

- Deir Abu Fana -Beni Khaled Minya monastery of the cross also Abu bane (الترتيب 139، المعرّف `MON_040`). توثق الكنيسة القبطية الأرثوذكسية ترميم الكنيسة التاريخية بدير أبي فانا بملوي وتدشينها. [المصدر](https://copticorthodox.church/en/2026/09/17/h-h-pope-tawadros-ii-inaugurates-the-historic-church-at-abu-fana-monastery-in-mallawi-following-its-restoration/)

- الكاتدرائية المرقسية (الترتيب 174، المعرّف `CHR-0006`). تذكر الكنيسة القبطية الأرثوذكسية كاتدرائية مارمرقس بمحطة الرمل ضمن تاريخ المقار البطريركية. [المصدر](https://copticorthodox.church/en/coptic-church/papal-residence/)

- كاتدرائية ميلاد المسيح (الترتيب 296، المعرّف `CHR-0070`). توثق رئاسة الجمهورية افتتاح كاتدرائية ميلاد المسيح بالعاصمة الإدارية في احتفال رسمي. [المصدر](https://www.presidency.eg/FR/%D9%82%D8%B3%D9%85-%D8%A7%D9%84%D8%A3%D8%AE%D8%A8%D8%A7%D8%B1/%D8%A3%D8%AE%D8%A8%D8%A7%D8%B1-%D8%B1%D8%A6%D8%A7%D8%B3%D9%8A%D8%A9/%D8%A7%D9%84%D8%B3%D9%8A%D8%AF-%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3-%D9%8A%D9%81%D8%AA%D8%AA%D8%AD-%D9%85%D8%B3%D8%AC%D8%AF-%D8%A7%D9%84%D9%81%D8%AA%D8%A7%D8%AD-%D8%A7%D9%84%D8%B9%D9%84%D9%8A%D9%85-%D9%88%D9%83%D8%A7%D8%AA%D8%AF%D8%B1%D8%A7%D8%A6%D9%8A%D8%A9-%D9%85%D9%8A%D9%84%D8%A7%D8%AF-%D8%A7%D9%84%D9%85%D8%B3%D9%8A%D8%AD-%D8%A8%D8%A7%D9%84%D8%B9%D8%A7%D8%B5%D9%85%D8%A9-%D8%A7%D9%84%D8%A5%D8%AF%D8%A7%D8%B1%D9%8A%D8%A9-%D8%A7%D9%84%D8%AC%D8%AF%D9%8A%D8%AF%D8%A9-%D9%88%D9%8A%D8%B4%D8%A7%D8%B1%D9%83-%D9%81%D9%8A-%D9%82%D8%AF%D8%A7%D8%B3-%D8%B9%D9%8A%D8%AF-%D8%A7%D9%84%D9%85%D9%8A%D9%84%D8%A7%D8%AF-%D8%A7%D9%84%D9%85%D8%AC%D9%8A%D8%AF-%D8%A8%D8%A7%D9%84%D9%83%D8%A7%D8%AA%D8%AF%D8%B1%D8%A7%D8%A6%D9%8A%D8%A9/)

- الإغريق الأرتدكس (الترتيب 297، المعرّف `CHR-0069`). توثق بطريركية الإسكندرية تاريخ بناء كنيسة البشارة بالإسكندرية واحتفال مرور 150 عامًا على وضع حجر الأساس. [المصدر](https://www.patriarchateofalexandria.com/the-church-of-the-annunciation-of-the-virgin-of-alexandria-celebrating-150-years-since-the-laying-of-the-foundation-stone/?lang=en)

بعد التحديث يوجد دليل مسجل لـ 23 من 322 موقعًا. عدد المواقع دون دليل أهمية مسجل هو 299.

## حدود التحقق

درجة النموذج تحدد الترتيب داخل القسم. تصنيف الأهمية التاريخية للمواقع الأخرى ما زال غير محسوم، ويتطلب ربط كل مكان بمصدر يحدد هويته وأهميته. ولا يتضمن هذا الفحص التحقق من مواعيد الزيارة أو إعادة تدريب النموذجين.
